#!/bin/bash
# Google Cloud Run Otomatik Deploy Script (Linux/Mac/Cloud Shell için)

PROJECT_ID="laststop-alarm-tr-38d76"
SERVICE_NAME="laststop-alarm-tr"
REGION="europe-west1"

echo "========================================"
echo "Google Cloud Run Deploy Script"
echo "========================================"
echo ""

# gcloud kontrolü
echo "[1/7] gcloud CLI kontrolü..."
if ! command -v gcloud &> /dev/null; then
    echo "❌ gcloud bulunamadı!"
    echo "Lütfen önce Google Cloud SDK'yı kurun"
    exit 1
fi
echo "✅ gcloud bulundu"
gcloud --version | head -n 1

# Proje ayarlama
echo ""
echo "[2/7] Proje ayarlanıyor: $PROJECT_ID"
gcloud config set project $PROJECT_ID
if [ $? -ne 0 ]; then
    echo "❌ Proje ayarlanamadı!"
    echo "Proje ID'nizi kontrol edin veya gcloud auth login yapın"
    exit 1
fi
echo "✅ Proje ayarlandı"

# API'leri aktifleştir
echo ""
echo "[3/7] Gerekli API'ler aktifleştiriliyor..."
gcloud services enable run.googleapis.com --quiet
gcloud services enable cloudbuild.googleapis.com --quiet
gcloud services enable containerregistry.googleapis.com --quiet
echo "✅ API'ler aktifleştirildi"

# Dockerfile kontrolü
echo ""
echo "[4/7] Dockerfile kontrolü..."
if [ ! -f "Dockerfile" ]; then
    echo "❌ Dockerfile bulunamadı!"
    exit 1
fi
echo "✅ Dockerfile bulundu"

# Deploy
echo ""
echo "[5/7] Cloud Run'a deploy ediliyor..."
echo "Bu işlem 5-10 dakika sürebilir..."
echo ""

# Google Maps API Key - Cloud Run environment variable veya Secret Manager'dan alınacak
# ÖNEMLİ: Production'da Secret Manager kullanılması önerilir (daha güvenli)
# Local development için .env dosyasında set edin
# 
# Seçenek 1: Environment variable (hızlı test için)
# Seçenek 2: Secret Manager (production için önerilir - USE_SECRET_MANAGER=true yapın)

USE_SECRET_MANAGER=${USE_SECRET_MANAGER:-false}

if [ "$USE_SECRET_MANAGER" = "true" ]; then
    echo "[5/7] Secret Manager'dan GOOGLE_MAPS_API_KEY alınıyor..."
    SECRET_NAME="google-maps-api-key"
    
    # Secret'ın var olup olmadığını kontrol et
    if ! gcloud secrets describe "$SECRET_NAME" --project "$PROJECT_ID" >/dev/null 2>&1; then
        echo "⚠️ Secret '$SECRET_NAME' bulunamadı. Oluşturuluyor..."
        echo "   Lütfen API key'inizi girin:"
        read -s apiKeyValue
        echo -n "$apiKeyValue" | gcloud secrets create "$SECRET_NAME" --data-file=- --project "$PROJECT_ID"
        if [ $? -ne 0 ]; then
            echo "❌ Secret oluşturulamadı!" >&2
            exit 1
        fi
    fi
    echo "✅ Secret Manager kullanılacak: $SECRET_NAME"
else
    # Environment variable kullan
    if [ -z "$GOOGLE_MAPS_API_KEY" ]; then
        echo "❌ HATA: GOOGLE_MAPS_API_KEY environment variable set edilmemiş!" >&2
        echo "   Cloud Run deployment için GOOGLE_MAPS_API_KEY environment variable'ı gereklidir." >&2
        echo "   Örnek: export GOOGLE_MAPS_API_KEY='your-api-key'" >&2
        echo "" >&2
        echo "   VEYA Secret Manager kullanmak için: USE_SECRET_MANAGER=true ./deploy-cloud-run.sh" >&2
        exit 1
    fi
    echo "✅ Environment variable kullanılıyor"
fi

# Deploy komutu (Secret Manager veya environment variable'a göre)
if [ "$USE_SECRET_MANAGER" = "true" ]; then
    # Secret Manager kullan
    gcloud run deploy $SERVICE_NAME \
        --source . \
        --region $REGION \
        --allow-unauthenticated \
        --memory 512Mi \
        --cpu 1 \
        --min-instances 0 \
        --max-instances 10 \
        --timeout 300 \
        --port 8080 \
        --update-secrets "GOOGLE_MAPS_API_KEY=$SECRET_NAME:latest" \
        --project $PROJECT_ID
else
    # Environment variable kullan
    gcloud run deploy $SERVICE_NAME \
        --source . \
        --region $REGION \
        --allow-unauthenticated \
        --memory 512Mi \
        --cpu 1 \
        --min-instances 0 \
        --max-instances 10 \
        --timeout 300 \
        --port 8080 \
        --set-env-vars "GOOGLE_MAPS_API_KEY=$GOOGLE_MAPS_API_KEY" \
        --project $PROJECT_ID
fi

if [ $? -ne 0 ]; then
    echo ""
    echo "❌ Deploy başarısız oldu!"
    echo "Logları kontrol edin: gcloud run services logs read $SERVICE_NAME --region $REGION"
    exit 1
fi

# Service URL'i al
echo ""
echo "[6/7] Service URL alınıyor..."
SERVICE_URL=$(gcloud run services describe $SERVICE_NAME --region $REGION --format "value(status.url)" --project $PROJECT_ID)

if [ -z "$SERVICE_URL" ]; then
    echo "❌ Service URL alınamadı!"
    exit 1
fi

echo ""
echo "========================================"
echo "✅ DEPLOY BAŞARILI!"
echo "========================================"
echo ""
echo "Service URL: $SERVICE_URL"
echo ""

# Healthcheck testi
echo "[7/7] Healthcheck testi yapılıyor..."
if curl -f -s "$SERVICE_URL/health" > /dev/null; then
    echo "✅ Healthcheck başarılı!"
    curl -s "$SERVICE_URL/health"
else
    echo "⚠️ Healthcheck testi başarısız"
    echo "Service URL'i manuel olarak test edin: $SERVICE_URL/health"
fi

# Places healthcheck (Google Places API yapılandırmasını kontrol eder)
echo ""
echo "Places healthcheck testi yapılıyor..."
if curl -f -s "$SERVICE_URL/places/health" > /dev/null; then
    placesHealthJson=$(curl -s "$SERVICE_URL/places/health")
    if echo "$placesHealthJson" | grep -q '"googlePlacesConfigured":true'; then
        echo "✅ Places API yapılandırılmış!"
    else
        echo "⚠️ Places API yapılandırılmamış!"
        echo "   GOOGLE_MAPS_API_KEY environment variable'ı kontrol edin"
    fi
    echo "Response: $placesHealthJson"
else
    echo "⚠️ Places healthcheck testi başarısız"
fi

echo ""
echo "========================================"
echo "SONRAKI ADIMLAR"
echo "========================================"
echo ""
echo "1. Production URL'i eas.json'a ekleyin:"
echo "   $SERVICE_URL"
echo ""
echo "2. VEYA EAS Secrets kullanın:"
echo "   # NOT: Transit API URL artık hardcoded (src/utils/env.ts), EAS Secret gerekmez"
echo ""
echo "3. API testi:"
echo "   curl \"$SERVICE_URL/stops/search?q=zincirlikuyu&limit=5\""
echo ""
echo "4. Logları görüntüle:"
echo "   gcloud run services logs read $SERVICE_NAME --region $REGION"
echo ""

# URL'i dosyaya kaydet
echo "$SERVICE_URL" > production-url.txt
echo "✅ Production URL 'production-url.txt' dosyasına kaydedildi"
echo ""

