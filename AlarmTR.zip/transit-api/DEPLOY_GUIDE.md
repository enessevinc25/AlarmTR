# Transit API - Google Cloud Run Deployment Guide

Bu rehber, transit-api backend'inizi Google Cloud Run'a deploy etmek için adım adım talimatlar içerir.

## 📋 Ön Gereksinimler

1. **Google Cloud SDK (gcloud CLI)** kurulu olmalı
   - Windows: https://cloud.google.com/sdk/docs/install
   - Mac: `brew install google-cloud-sdk`
   - Linux: https://cloud.google.com/sdk/docs/install

2. **Google Cloud Projesi** oluşturulmuş olmalı
   - Project ID: `laststop-alarm-tr-38d76`

3. **Google Cloud'a giriş yapılmış** olmalı
   ```powershell
   gcloud auth login
   gcloud config set project laststop-alarm-tr-38d76
   ```

## 🔐 Google Maps API Key Yapılandırması

**⚠️ ÖNEMLİ:** Backend için **SERVER-SIDE** API key gerekiyor!

Mobil uygulama key'leri (Android/iOS) client-side için. Backend'de ayrı bir server-side key oluşturun:
- **Google Cloud Console** → **APIs & Services** → **Credentials** → **Create API Key**
- **Application restrictions**: IP addresses (Cloud Run IP'leri)
- **API restrictions**: Places API

### Seçenek 1: Secret Manager (Önerilen - Production için)

Secret Manager daha güvenlidir ve API key'lerinizi güvenli bir şekilde saklar.

#### Secret Oluşturma

```powershell
# PowerShell
$apiKey = Read-Host -AsSecureString -Prompt "Google Maps API Key'inizi girin"
$apiKeyPlain = [Runtime.InteropServices.Marshal]::PtrToStringAuto([Runtime.InteropServices.Marshal]::SecureStringToBSTR($apiKey))
echo $apiKeyPlain | gcloud secrets create google-maps-api-key --data-file=- --project laststop-alarm-tr-38d76

# Bash
echo -n "your-google-maps-api-key" | gcloud secrets create google-maps-api-key --data-file=- --project laststop-alarm-tr-38d76
```

#### Secret Manager ile Deploy

```powershell
# PowerShell - Script'te USE_SECRET_MANAGER=true yapın veya:
$env:USE_SECRET_MANAGER="true"
cd transit-api
.\deploy-cloud-run.ps1

# Bash
USE_SECRET_MANAGER=true ./deploy-cloud-run.sh
```

### Seçenek 2: Environment Variable (Hızlı Test için)

```powershell
# PowerShell
$env:GOOGLE_MAPS_API_KEY="your-google-maps-api-key-here"
cd transit-api
.\deploy-cloud-run.ps1

# Bash
export GOOGLE_MAPS_API_KEY="your-google-maps-api-key-here"
cd transit-api
./deploy-cloud-run.sh
```

## 🚀 Deploy Adımları

### 1. Gerekli API'leri Aktifleştir

```powershell
gcloud services enable run.googleapis.com --project laststop-alarm-tr-38d76
gcloud services enable cloudbuild.googleapis.com --project laststop-alarm-tr-38d76
gcloud services enable containerregistry.googleapis.com --project laststop-alarm-tr-38d76
gcloud services enable secretmanager.googleapis.com --project laststop-alarm-tr-38d76  # Secret Manager için
```

### 2. Deploy Script'ini Çalıştır

#### Windows (PowerShell)

```powershell
cd transit-api

# Environment variable ile (hızlı test)
$env:GOOGLE_MAPS_API_KEY="your-api-key"
.\deploy-cloud-run.ps1

# VEYA Secret Manager ile (production)
$env:USE_SECRET_MANAGER="true"
.\deploy-cloud-run.ps1
```

#### Linux/Mac (Bash)

```bash
cd transit-api

# Environment variable ile (hızlı test)
export GOOGLE_MAPS_API_KEY="your-api-key"
./deploy-cloud-run.sh

# VEYA Secret Manager ile (production)
USE_SECRET_MANAGER=true ./deploy-cloud-run.sh
```

### 3. Deploy Sonrası Kontroller

Script otomatik olarak şunları yapar:
- ✅ Healthcheck testi (`/health`)
- ✅ Places healthcheck testi (`/places/health`) - Google Maps API yapılandırmasını kontrol eder
- ✅ Service URL'i `production-url.txt` dosyasına kaydeder

### 4. Manuel Test

```powershell
# Service URL'i al
$SERVICE_URL = gcloud run services describe laststop-alarm-tr --region europe-west1 --format "value(status.url)" --project laststop-alarm-tr-38d76

# Healthcheck
curl "$SERVICE_URL/health"

# Places healthcheck
curl "$SERVICE_URL/places/health"

# API test
curl "$SERVICE_URL/stops/search?q=zincirlikuyu&limit=5"
```

## 🔄 Güncelleme

### Kod Değişikliği Sonrası

```powershell
cd transit-api
.\deploy-cloud-run.ps1  # Aynı script'i tekrar çalıştırın
```

### API Key Güncelleme

#### Secret Manager Kullanıyorsanız

```powershell
# Yeni secret version ekle
echo -n "your-new-api-key" | gcloud secrets versions add google-maps-api-key --data-file=- --project laststop-alarm-tr-38d76

# Cloud Run service'i güncelle (secret otomatik olarak latest version'ı kullanır)
gcloud run services update laststop-alarm-tr --region europe-west1 --update-secrets "GOOGLE_MAPS_API_KEY=google-maps-api-key:latest" --project laststop-alarm-tr-38d76
```

#### Environment Variable Kullanıyorsanız

```powershell
gcloud run services update laststop-alarm-tr --region europe-west1 --set-env-vars "GOOGLE_MAPS_API_KEY=your-new-api-key" --project laststop-alarm-tr-38d76
```

## 📊 Cloud Run Service Ayarları

Mevcut service ayarları:
- **Memory**: 512Mi
- **CPU**: 1
- **Min Instances**: 0 (cold start olabilir)
- **Max Instances**: 10
- **Timeout**: 300 saniye (5 dakika)
- **Port**: 8080
- **Region**: europe-west1

Bu ayarları değiştirmek için:

```powershell
gcloud run services update laststop-alarm-tr --region europe-west1 --memory 1Gi --cpu 2 --project laststop-alarm-tr-38d76
```

## 📝 Loglar

```powershell
# Son logları görüntüle
gcloud run services logs read laststop-alarm-tr --region europe-west1 --project laststop-alarm-tr-38d76

# Canlı log takibi
gcloud run services logs tail laststop-alarm-tr --region europe-west1 --project laststop-alarm-tr-38d76
```

## 🔍 Troubleshooting

### Deploy Başarısız Olursa

1. **gcloud CLI kontrolü**
   ```powershell
   gcloud --version
   gcloud auth list
   ```

2. **Proje kontrolü**
   ```powershell
   gcloud config get-value project
   ```

3. **API'ler aktif mi?**
   ```powershell
   gcloud services list --enabled --project laststop-alarm-tr-38d76
   ```

4. **Logları kontrol et**
   ```powershell
   gcloud run services logs read laststop-alarm-tr --region europe-west1 --project laststop-alarm-tr-38d76 --limit 50
   ```

### Places API Çalışmıyorsa

1. **Places healthcheck test et**
   ```powershell
   curl "$SERVICE_URL/places/health"
   ```

2. **Environment variable kontrol et**
   ```powershell
   gcloud run services describe laststop-alarm-tr --region europe-west1 --format "value(spec.template.spec.containers[0].env)" --project laststop-alarm-tr-38d76
   ```

3. **Secret Manager kontrol et**
   ```powershell
   gcloud secrets versions access latest --secret="google-maps-api-key" --project laststop-alarm-tr-38d76
   ```

## 📚 Daha Fazla Bilgi

- [Google Cloud Run Dokümantasyonu](https://cloud.google.com/run/docs)
- [Secret Manager Dokümantasyonu](https://cloud.google.com/secret-manager/docs)
- [Cloud Build Dokümantasyonu](https://cloud.google.com/build/docs)

