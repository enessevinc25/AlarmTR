/**
 * NOTE: Bu dosya sadece offline/fallback senaryolar için hazırlanmıştır.
 * 
 * Runtime'da transit verisi İBB CKAN Data API üzerinden geliyor (clients/ibbCkanClient.ts).
 * 
 * ⚠️ KULLANILMIYOR: Bu dosyadaki loadTransitData() fonksiyonu şu anda hiçbir yerde import edilmiyor.
 * 
 * İleride offline mode veya API erişim sorunlarında fallback olarak kullanılabilir.
 * Şu an için data/ klasöründeki JSON dosyaları placeholder olarak duruyor.
 */

import fs from 'fs';
import path from 'path';
import { TransitLine, TransitStop, LineStopRelation } from './types/transit';

interface TransitData {
  stops: TransitStop[];
  lines: TransitLine[];
  lineStops: LineStopRelation[];
}

let cache: TransitData | null = null;

export function loadTransitData(): TransitData {
  if (cache) {
    return cache;
  }

  const baseDir = path.join(__dirname, '..', 'data');

  const stopsRaw = fs.readFileSync(path.join(baseDir, 'stops.json'), 'utf-8');
  const linesRaw = fs.readFileSync(path.join(baseDir, 'lines.json'), 'utf-8');
  const lineStopsRaw = fs.readFileSync(path.join(baseDir, 'lineStops.json'), 'utf-8');

  const stops: TransitStop[] = JSON.parse(stopsRaw);
  const lines: TransitLine[] = JSON.parse(linesRaw);
  const lineStops: LineStopRelation[] = JSON.parse(lineStopsRaw);

  cache = { stops, lines, lineStops };
  return cache;
}

