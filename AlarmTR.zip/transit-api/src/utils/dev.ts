/**
 * Development mode utility for backend
 * In Node.js, we use process.env.NODE_ENV instead of __DEV__
 */

export const __DEV__ = process.env.NODE_ENV !== 'production';

