import dotenv from 'dotenv';
import { __DEV__ } from '../utils/dev';

dotenv.config();

/**
 * Ulasav CKAN API Configuration
 * Yeni GTFS tabanlı CKAN API'si için environment değişkenleri
 */

export const ULS_CKAN_BASE_URL =
  process.env.ULS_CKAN_BASE_URL || 'https://ulasav.csb.gov.tr/api/3/action';

export const ULS_ROUTES_RESOURCE_ID = process.env.ULS_ROUTES_RESOURCE_ID;
export const ULS_TRIPS_RESOURCE_ID = process.env.ULS_TRIPS_RESOURCE_ID;
export const ULS_STOPS_RESOURCE_ID = process.env.ULS_STOPS_RESOURCE_ID;
export const ULS_STOP_TIMES_RESOURCE_ID = process.env.ULS_STOP_TIMES_RESOURCE_ID;

// Validation
if (!ULS_ROUTES_RESOURCE_ID) {
  if (__DEV__) {
    console.warn('[env] ULS_ROUTES_RESOURCE_ID tanımlı değil, route işlemleri çalışmayabilir.');
  }
}

if (!ULS_TRIPS_RESOURCE_ID) {
  if (__DEV__) {
    console.warn('[env] ULS_TRIPS_RESOURCE_ID tanımlı değil, trip işlemleri çalışmayabilir.');
  }
}

if (!ULS_STOPS_RESOURCE_ID) {
  if (__DEV__) {
    console.warn('[env] ULS_STOPS_RESOURCE_ID tanımlı değil, stop işlemleri çalışmayabilir.');
  }
}

if (!ULS_STOP_TIMES_RESOURCE_ID) {
  if (__DEV__) {
    console.warn('[env] ULS_STOP_TIMES_RESOURCE_ID tanımlı değil, stop_times işlemleri çalışmayabilir.');
  }
}

/**
 * IETT Web Services Configuration
 * İBB IETT SOAP web servisleri için environment değişkenleri
 */
export const iettConfig = {
  baseUrl: process.env.IETT_BASE_URL ?? 'https://api.ibb.gov.tr/iett',
  hatDurakEndpoint:
    (process.env.IETT_BASE_URL ?? 'https://api.ibb.gov.tr/iett') +
    '/UlasimAnaVeri/HatDurakGuzergah.asmx',
  ibbEndpoint:
    (process.env.IETT_BASE_URL ?? 'https://api.ibb.gov.tr/iett') + '/ibb/ibb.asmx',
};

if (!process.env.IETT_BASE_URL) {
  if (__DEV__) {
    console.warn(
    '[env] IETT_BASE_URL tanımlı değil, varsayılan değer kullanılıyor: https://api.ibb.gov.tr/iett'
  );
  }
}

