import express from 'express';
import cors from 'cors';
import dotenv from 'dotenv';
import rateLimit from 'express-rate-limit';
import { __DEV__ } from './utils/dev';
import {
  getAllStopsFromIett,
  searchStopsByNameOrCode,
  getAllLinesFromIett,
  searchLinesByQuery,
  getLineStopsFromIett,
  getStopByIdFromIett,
} from './clients/iettClient';
dotenv.config();

const app = express();
// Cloud Run PORT env var'ını kullan, yoksa 4000 (local development)
// Cloud Run otomatik olarak PORT env var'ını set eder
const port = Number(process.env.PORT) || 4000;

// Cloud Run için trust proxy (x-forwarded-for doğru gelsin)
app.set('trust proxy', 1);

app.use(cors());
app.use(express.json());

// IP tespiti için helper (Cloud Run proxy için x-forwarded-for desteği)
const getClientIp = (req: express.Request): string => {
  const xff = req.headers['x-forwarded-for'];
  if (typeof xff === 'string') { 
    return xff.split(',')[0].trim();
  }
  return req.ip || req.socket.remoteAddress || 'unknown';
};

// Rate limiting (P0: abuse/DDoS riskini azalt)
// Global limiter: 15 dakika içinde max 300 istek
const globalLimiter = rateLimit({
  windowMs: 15 * 60 * 1000, // 15 dakika
  max: 300, // Her IP için max 300 istek
  message: { error: 'Çok fazla istek gönderildi. Lütfen daha sonra tekrar deneyin.' },
  standardHeaders: true, // `RateLimit-*` headers'ı ekle
  legacyHeaders: false, // `X-RateLimit-*` headers'ı ekleme
  keyGenerator: (req) => getClientIp(req),
});

// /places için limiter: 15 dakika içinde max 300 istek (artırıldı)
const placesLimiter = rateLimit({
  windowMs: 15 * 60 * 1000, // 15 dakika
  max: 300, // Her IP için max 300 istek (100'den 300'e artırıldı)
  message: { error: 'Yer araması için çok fazla istek gönderildi. Lütfen daha sonra tekrar deneyin.' },
  standardHeaders: true,
  legacyHeaders: false,
  keyGenerator: (req) => getClientIp(req),
});

// Global limiter'ı tüm route'lara uygula (health ve /places/health hariç)
app.use((req, res, next) => {
  if (req.path === '/health' || req.path === '/places/health') {
    return next(); // Health endpoint'leri limiter'dan muaf
  }
  globalLimiter(req, res, next);
});

// Basit healthcheck
app.get('/health', (_req, res) => {
  res.json({ ok: true, message: 'Transit API up' });
});

// Places healthcheck (Google Places API yapılandırmasını kontrol eder, KEY'i asla döndürmez)
app.get('/places/health', (_req, res) => {
  const googlePlacesConfigured = !!process.env.GOOGLE_MAPS_API_KEY;
  res.json({ 
    ok: true, 
    googlePlacesConfigured,
    message: googlePlacesConfigured 
      ? 'Google Places API yapılandırılmış' 
      : 'Google Places API yapılandırılmamış'
  });
});

// GET /stops/search
app.get('/stops/search', async (req, res) => {
  try {
    const q = (req.query.q as string | undefined) ?? '';
    const limit = Number(req.query.limit ?? 25) || 25;

    if (!q || q.trim().length < 2) {
      return res.json({ stops: [] });
    }

    if (__DEV__) {
      console.log(`[GET /stops/search] query="${q}", limit=${limit}`);
    }
    const stops = await searchStopsByNameOrCode(q, limit);
    if (__DEV__) {
      console.log(`[GET /stops/search] found ${stops.length} stops`);
    }
    res.json({ stops });
  } catch (error: any) {
    // Kritik hatalar prod'da da loglanmalı
    console.error('[GET /stops/search] error:', error);
    const errorMessage = error?.message || 'Bilinmeyen hata';
    const statusCode = error?.status || 500;
    res.status(statusCode).json({ 
      error: 'Durak araması sırasında hata oluştu.',
      details: process.env.NODE_ENV === 'development' ? errorMessage : undefined
    });
  }
});

// GET /lines
app.get('/lines', async (req, res) => {
  try {
    const mode = req.query.mode as string | undefined;
    const q = (req.query.q as string | undefined) ?? '';

    if (__DEV__) {
      console.log(`[GET /lines] mode="${mode}", query="${q}"`);
    }
    const lines = q ? await searchLinesByQuery(q) : await getAllLinesFromIett();

    // Mode filtresi varsa uygula
    const filtered = mode ? lines.filter((line) => line.mode === mode) : lines;

    if (__DEV__) {
      console.log(`[GET /lines] found ${filtered.length} lines`);
    }
    res.json({ lines: filtered });
  } catch (error: any) {
    // Kritik hatalar prod'da da loglanmalı
    console.error('[GET /lines] error:', error);
    const errorMessage = error?.message || 'Bilinmeyen hata';
    const statusCode = error?.status || 500;
    res.status(statusCode).json({ 
      error: 'Hat listesi alınırken bir hata oluştu.',
      details: process.env.NODE_ENV === 'development' ? errorMessage : undefined
    });
  }
});

// GET /lines/:lineId/stops
app.get('/lines/:lineId/stops', async (req, res) => {
  try {
    const lineId = req.params.lineId;

    if (!lineId) {
      return res.status(400).json({ error: 'Hat kodu gerekli' });
    }

    if (__DEV__) {
      console.log(`[GET /lines/${lineId}/stops] fetching stops for line`);
    }
    const { line, stops } = await getLineStopsFromIett(lineId);

    if (!line || !stops.length) {
      if (__DEV__) {
        console.warn(`[GET /lines/${lineId}/stops] line or stops not found`);
      }
      return res.status(404).json({ error: 'Hat veya durakları bulunamadı' });
    }

    if (__DEV__) {
      console.log(`[GET /lines/${lineId}/stops] found ${stops.length} stops`);
    }
    res.json({ line, stops });
  } catch (error: any) {
    // Kritik hatalar prod'da da loglanmalı
    console.error(`[GET /lines/${req.params.lineId}/stops] error:`, error);
    const errorMessage = error?.message || 'Bilinmeyen hata';
    const statusCode = error?.status || 500;
    res.status(statusCode).json({ 
      error: 'Hat durakları alınırken hata oluştu.',
      details: process.env.NODE_ENV === 'development' ? errorMessage : undefined
    });
  }
});

// GET /stops/:stopId
app.get('/stops/:stopId', async (req, res) => {
  try {
    const stopId = req.params.stopId;
    if (__DEV__) {
      console.log(`[GET /stops/${stopId}] fetching stop details`);
    }
    const stop = await getStopByIdFromIett(stopId);

    if (!stop) {
      if (__DEV__) {
        console.warn(`[GET /stops/${stopId}] stop not found`);
      }
      return res.status(404).json({ error: 'Durak bulunamadı' });
    }

    if (__DEV__) {
      console.log(`[GET /stops/${stopId}] stop found: ${stop.name}`);
    }
    res.json({ stop });
  } catch (error: any) {
    // Kritik hatalar prod'da da loglanmalı
    console.error(`[GET /stops/${req.params.stopId}] error:`, error);
    const errorMessage = error?.message || 'Bilinmeyen hata';
    const statusCode = error?.status || 500;
    res.status(statusCode).json({ 
      error: 'Durak bilgisi alınırken hata oluştu.',
      details: process.env.NODE_ENV === 'development' ? errorMessage : undefined
    });
  }
});

// GET /places/autocomplete - Google Places Autocomplete proxy
app.get('/places/autocomplete', placesLimiter, async (req, res) => {
  try {
    const input = (req.query.input as string | undefined)?.trim();
    const language = (req.query.language as string | undefined) || 'tr';
    const components = (req.query.components as string | undefined) || 'country:tr';

    // Max length kontrolü (DoS önleme)
    if (input && input.length > 200) {
      return res.status(400).json({ error: 'input parametresi çok uzun (max 200 karakter)' });
    }

    if (!input || input.length < 2) {
      return res.status(400).json({ error: 'input parametresi en az 2 karakter olmalı' });
    }

    const apiKey = process.env.GOOGLE_MAPS_API_KEY;
    if (!apiKey) {
      if (__DEV__) {
        console.error('[GET /places/autocomplete] GOOGLE_MAPS_API_KEY env var not set');
      }
      return res.status(503).json({ error: 'Google Places API yapılandırması eksik' });
    }

    const url = `https://maps.googleapis.com/maps/api/place/autocomplete/json?input=${encodeURIComponent(input)}&key=${encodeURIComponent(apiKey)}&language=${encodeURIComponent(language)}&components=${encodeURIComponent(components)}`;

    const response = await fetch(url);
    if (!response.ok) {
      if (__DEV__) {
        console.error(`[GET /places/autocomplete] Google API HTTP ${response.status}`);
      }
      return res.status(502).json({ error: 'Google Places API hatası' });
    }

    const jsonUnknown: unknown = await response.json();
    const json = (jsonUnknown && typeof jsonUnknown === 'object') ? (jsonUnknown as Record<string, any>) : {};

    // API key hatası kontrolü
    if (json.status === 'REQUEST_DENIED') {
      const errorMsg = json.error_message || 'Google Places API erişim reddedildi';
      if (__DEV__) {
        console.error('[GET /places/autocomplete] API key rejected:', errorMsg);
      }
      return res.status(502).json({ error: 'Google Places API erişim reddedildi' });
    }

    // Quota aşımı kontrolü
    if (json.status === 'OVER_QUERY_LIMIT') {
      if (__DEV__) {
        console.error('[GET /places/autocomplete] Quota exceeded');
      }
      return res.status(502).json({ error: 'Google Places API kotası aşıldı' });
    }

    if (json.status !== 'OK' && json.status !== 'ZERO_RESULTS') {
      const errorMsg = json.error_message || json.status;
      if (__DEV__) {
        console.warn('[GET /places/autocomplete] error:', json.status, errorMsg);
      }
      return res.status(502).json({ error: `Google Places API hatası: ${errorMsg}` });
    }

    const predictions = Array.isArray(json.predictions) ? json.predictions : [];

    // Mobilin beklediği minimal shape'e map et
    const suggestions = predictions.map((p: any) => ({
      placeId: p.place_id,
      description: p.description ?? '',
      structured_formatting: p.structured_formatting,
    }));

    res.json({ suggestions });
  } catch (error: any) {
    // Kritik hatalar prod'da da loglanmalı
    console.error('[GET /places/autocomplete] error:', error);
    const errorMessage = error?.message || 'Bilinmeyen hata';
    res.status(500).json({ 
      error: 'Yer araması sırasında hata oluştu.',
      details: process.env.NODE_ENV === 'development' ? errorMessage : undefined
    });
  }
});

// GET /places/details - Google Place Details proxy
app.get('/places/details', placesLimiter, async (req, res) => {
  try {
    const placeId = (req.query.placeId as string | undefined)?.trim();
    const language = (req.query.language as string | undefined) || 'tr';

    if (!placeId) {
      return res.status(400).json({ error: 'placeId parametresi gerekli' });
    }

    const apiKey = process.env.GOOGLE_MAPS_API_KEY;
    if (!apiKey) {
      if (__DEV__) {
        console.error('[GET /places/details] GOOGLE_MAPS_API_KEY env var not set');
      }
      return res.status(503).json({ error: 'Google Places API yapılandırması eksik' });
    }

    const url = `https://maps.googleapis.com/maps/api/place/details/json?place_id=${encodeURIComponent(placeId)}&key=${encodeURIComponent(apiKey)}&language=${encodeURIComponent(language)}&fields=name,geometry,formatted_address`;

    const response = await fetch(url);
    if (!response.ok) {
      if (__DEV__) {
        console.error(`[GET /places/details] Google API HTTP ${response.status}`);
      }
      return res.status(502).json({ error: 'Google Places API hatası' });
    }

    const jsonUnknown: unknown = await response.json();
    const json = (jsonUnknown && typeof jsonUnknown === 'object') ? (jsonUnknown as Record<string, any>) : {};

    // API key hatası kontrolü
    if (json.status === 'REQUEST_DENIED') {
      const errorMsg = json.error_message || 'Google Places API erişim reddedildi';
      if (__DEV__) {
        console.error('[GET /places/details] API key rejected:', errorMsg);
      }
      return res.status(502).json({ error: 'Google Places API erişim reddedildi' });
    }

    // Quota aşımı kontrolü
    if (json.status === 'OVER_QUERY_LIMIT') {
      if (__DEV__) {
        console.error('[GET /places/details] Quota exceeded');
      }
      return res.status(502).json({ error: 'Google Places API kotası aşıldı' });
    }

    if (json.status === 'NOT_FOUND') {
      if (__DEV__) {
        console.warn('[GET /places/details] Place not found:', placeId);
      }
      return res.status(404).json({ error: 'Yer bulunamadı' });
    }

    if (json.status !== 'OK') {
      const errorMsg = json.error_message || json.status;
      if (__DEV__) {
        console.warn('[GET /places/details] error:', json.status, errorMsg);
      }
      return res.status(502).json({ error: `Yer detayları alınamadı: ${errorMsg}` });
    }

    const result = json.result;

    if (!result || !result.geometry || !result.geometry.location) {
      if (__DEV__) {
        console.warn('[GET /places/details] Invalid place details structure:', result);
      }
      return res.status(502).json({ error: 'Geçersiz yer detayları yapısı' });
    }

    const loc = result.geometry.location;

    // Mobilin beklediği shape'e map et
    res.json({
      placeId,
      name: result.name ?? '',
      latitude: loc.lat,
      longitude: loc.lng,
      address: result.formatted_address ?? '',
    });
  } catch (error: any) {
    // Kritik hatalar prod'da da loglanmalı
    console.error('[GET /places/details] error:', error);
    const errorMessage = error?.message || 'Bilinmeyen hata';
    res.status(500).json({ 
      error: 'Yer detayları alınırken hata oluştu.',
      details: process.env.NODE_ENV === 'development' ? errorMessage : undefined
    });
  }
});

// 404 handler for unknown routes
app.use((_req, res) => {
  res.status(404).json({ error: 'Route not found' });
});

// Export app for testing
export default app;

// Cloud Run için: PORT env var'ını kullan, host'u 0.0.0.0 yap
// Local development için: HOST env var'ını kullan veya 0.0.0.0
// Only start server if not in test environment
if (process.env.NODE_ENV !== 'test' && require.main === module) {
  const host = process.env.HOST || '0.0.0.0';
  app.listen(port, host, () => {
    if (__DEV__) {
      console.log(`Transit API listening on http://${host}:${port}`);
      console.log(`Local network access: http://<your-local-ip>:${port}`);
    }
  });
}

