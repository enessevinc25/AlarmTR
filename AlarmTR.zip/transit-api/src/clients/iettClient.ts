import dotenv from 'dotenv';
import { TransitLine, TransitMode, TransitStop } from '../types/transit';
import { haversineDistanceMeters } from '../utils/geo';
import { __DEV__ } from '../utils/dev';

dotenv.config();

const CKAN_BASE_URL =
  process.env.IMM_CKAN_BASE_URL || 'https://data.ibb.gov.tr/en/api/3/action';

const STOPS_RESOURCE_ID = process.env.IMM_STOPS_RESOURCE_ID;
const ROUTES_RESOURCE_ID = process.env.IMM_ROUTES_RESOURCE_ID;
const TRIPS_RESOURCE_ID = process.env.IMM_TRIPS_RESOURCE_ID;
const STOP_TIMES_RESOURCE_ID = process.env.IMM_STOP_TIMES_RESOURCE_ID;

if (!STOPS_RESOURCE_ID) {
  if (__DEV__) {
    console.warn('[ibbCkanClient] IMM_STOPS_RESOURCE_ID tanımlı değil, API çağrıları hata verebilir.');
  }
}
if (!ROUTES_RESOURCE_ID) {
  if (__DEV__) {
    console.warn('[ibbCkanClient] IMM_ROUTES_RESOURCE_ID tanımlı değil, API çağrıları hata verebilir.');
  }
}
if (!TRIPS_RESOURCE_ID) {
  if (__DEV__) {
    console.warn('[ibbCkanClient] IMM_TRIPS_RESOURCE_ID tanımlı değil, /lines/:id/stops eksik çalışabilir.');
  }
}
if (!STOP_TIMES_RESOURCE_ID) {
  if (__DEV__) {
    console.warn('[ibbCkanClient] IMM_STOP_TIMES_RESOURCE_ID tanımlı değil, /lines/:id/stops eksik çalışabilir.');
  }
}

interface CkanDatastoreSearchResult<TRecord> {
  records: TRecord[];
  total: number;
}

interface CkanDatastoreSearchResponse<TRecord> {
  success: boolean;
  result: CkanDatastoreSearchResult<TRecord>;
}

// GTFS stops tablosu kaydı (CKAN Data API'den gelen)
interface IbbGtfsStopRecord {
  stop_id: string;
  stop_name: string;
  stop_lat: number | string;
  stop_lon: number | string;
  stop_code?: string;
  // Diğer kolonlar da gelebilir, yok sayabiliriz
  [key: string]: any;
}

// GTFS routes tablosu kaydı
interface IbbGtfsRouteRecord {
  route_id: string;
  route_short_name: string;
  route_long_name: string;
  route_type: number | string;
  [key: string]: any;
}

// GTFS trips tablosu kaydı
interface IbbGtfsTripRecord {
  trip_id: string;
  route_id: string;
  direction_id?: number | string;
  [key: string]: any;
}

// GTFS stop_times tablosu kaydı
interface IbbGtfsStopTimeRecord {
  trip_id: string;
  stop_id: string;
  stop_sequence: number | string;
  arrival_time?: string;
  departure_time?: string;
  [key: string]: any;
}

async function ckanDatastoreSearch<TRecord>(
  resourceId: string,
  params: Record<string, string | number | undefined> = {}
): Promise<CkanDatastoreSearchResult<TRecord>> {
  const url = new URL(`${CKAN_BASE_URL}/datastore_search`);
  url.searchParams.set('resource_id', resourceId);

  Object.entries(params).forEach(([key, value]) => {
    if (value !== undefined) {
      url.searchParams.set(key, String(value));
    }
  });

  const res = await fetch(url.toString());
  if (!res.ok) {
    throw new Error(`CKAN datastore_search error ${res.status} for resource ${resourceId}`);
  }
  const jsonUnknown: unknown = await res.json();
  const json = (jsonUnknown && typeof jsonUnknown === 'object') ? (jsonUnknown as CkanDatastoreSearchResponse<TRecord>) : { success: false, result: { records: [], total: 0 } } as CkanDatastoreSearchResponse<TRecord>;
  if (!json.success) {
    throw new Error(`CKAN datastore_search success=false for resource ${resourceId}`);
  }
  return json.result;
}

// route_type → TransitMode dönüşümü (GTFS standardına yakın)
function mapRouteTypeToMode(routeType: number): TransitMode {
  switch (routeType) {
    case 0:
      return 'TRAM';
    case 1:
      return 'METRO'; // light rail / metro benzeri
    case 3:
      return 'BUS';
    case 4:
      return 'FERRY';
    default:
      return 'BUS';
  }
}

function mapStopRecordToTransitStop(rec: IbbGtfsStopRecord): TransitStop {
  const lat = typeof rec.stop_lat === 'string' ? parseFloat(rec.stop_lat) : rec.stop_lat;
  const lon = typeof rec.stop_lon === 'string' ? parseFloat(rec.stop_lon) : rec.stop_lon;

  // stop_name boş/null ise en azından id ile doldur
  const safeName = rec.stop_name && rec.stop_name.trim().length > 0
    ? rec.stop_name
    : rec.stop_id;

  return {
    id: rec.stop_id,
    code: rec.stop_code ?? rec.stop_id,
    name: safeName,
    latitude: lat,
    longitude: lon,
    modes: ['BUS'],
    lineIds: [],
  };
}

function mapRouteRecordToTransitLine(rec: IbbGtfsRouteRecord): TransitLine {
  const typeNum =
    typeof rec.route_type === 'string' ? parseInt(rec.route_type, 10) : rec.route_type;

  return {
    id: rec.route_id,
    code: rec.route_short_name || rec.route_id,
    name: rec.route_long_name || rec.route_short_name || rec.route_id,
    mode: mapRouteTypeToMode(typeNum),
  };
}

// ======== DURAKLAR İÇİN CACHE ==========

let stopsCache: TransitStop[] | null = null;
let stopsCacheLoadedAt: number | null = null;
// STOPS_CACHE_TTL_MS defined at line 763 (6 hours)

export async function getAllStopsFromIbb(): Promise<TransitStop[]> {
  if (!STOPS_RESOURCE_ID) {
    throw new Error('IMM_STOPS_RESOURCE_ID tanımlı değil');
  }

  const now = Date.now();
  if (stopsCache && stopsCacheLoadedAt && now - stopsCacheLoadedAt < STOPS_CACHE_TTL_MS) {
    return stopsCache;
  }

  const pageSize = 1000;
  let offset = 0;
  let allRecords: IbbGtfsStopRecord[] = [];

  // sayfalı şekilde tüm durakları çek
  // total'a bakarak offset'i ilerlet
  // (CKAN datastore_search limit+offset destekliyor)
  while (true) {
    const result = await ckanDatastoreSearch<IbbGtfsStopRecord>(STOPS_RESOURCE_ID, {
      limit: pageSize,
      offset,
    });

    allRecords = allRecords.concat(result.records);

    if (result.records.length < pageSize) {
      break;
    }
    offset += pageSize;
  }

  const mapped = allRecords.map(mapStopRecordToTransitStop);
  stopsCache = mapped;
  stopsCacheLoadedAt = now;
  return mapped;
}

export async function searchStopsFromIbb(query: string, limit = 25): Promise<TransitStop[]> {
  const trimmed = query.trim();
  if (!trimmed || trimmed.length < 2) {
    return [];
  }

  const allStops = await getAllStopsFromIbb();
  const qLower = trimmed.toLocaleLowerCase('tr-TR');

  const filtered = allStops.filter((stop) => {
    // Bazı kayıtların name'i null/undefined olabiliyor, bu yüzden güvenli cast yap
    const name = (stop.name ?? '').toLocaleLowerCase('tr-TR');
    const code = (stop.code ?? '').toLocaleLowerCase('tr-TR');
    return name.includes(qLower) || code.includes(qLower);
  });

  return filtered.slice(0, limit);
}
 

export async function getNearbyStopsFromIbb(
  lat: number,
  lon: number,
  radiusMeters: number,
  limit: number
): Promise<TransitStop[]> {
  const allStops = await getAllStopsFromIbb();

  const withDistance = allStops.map((stop) => {
    const distance = haversineDistanceMeters(
      lat,
      lon,
      stop.latitude,
      stop.longitude
    );
    return { stop, distance };
  });

  const filtered = withDistance
    .filter((item) => item.distance <= radiusMeters)
    .sort((a, b) => a.distance - b.distance)
    .slice(0, limit)
    .map((item) => item.stop);

  return filtered;
}

// ======== HATLAR (ROUTES) ==========

let linesCache: TransitLine[] | null = null;
let linesCacheLoadedAt: number | null = null;
// LINES_CACHE_TTL_MS moved to line 764 to avoid duplicate

export async function getAllLinesFromIbb(): Promise<TransitLine[]> {
  if (!ROUTES_RESOURCE_ID) {
    throw new Error('IMM_ROUTES_RESOURCE_ID tanımlı değil');
  }

  const now = Date.now();
  if (linesCache && linesCacheLoadedAt && now - linesCacheLoadedAt < LINES_CACHE_TTL_MS) {
    return linesCache;
  }

  const pageSize = 1000;
  let offset = 0;
  let allRecords: IbbGtfsRouteRecord[] = [];

  while (true) {
    const result = await ckanDatastoreSearch<IbbGtfsRouteRecord>(ROUTES_RESOURCE_ID, {
      limit: pageSize,
      offset,
    });

    allRecords = allRecords.concat(result.records);

    if (result.records.length < pageSize) {
      break;
    }
    offset += pageSize;
  }

  const mapped = allRecords.map(mapRouteRecordToTransitLine);
  linesCache = mapped;
  linesCacheLoadedAt = now;
  return mapped;
}

// ======== HAT DURAKLARI (LINE STOPS) ==========

export async function getLineStopsFromIbb(routeId: string): Promise<TransitStop[]> {
  if (!TRIPS_RESOURCE_ID || !STOP_TIMES_RESOURCE_ID) {
    if (__DEV__) {
      console.warn(
      '[getLineStopsFromIbb] TRIPS_RESOURCE_ID veya STOP_TIMES_RESOURCE_ID tanımlı değil, boş dizi döndürülüyor.'
    );
    }
    return [];
  }

  try {
    // 1. İlgili route_id için bir temsilci trip çek
    const tripsResult = await ckanDatastoreSearch<IbbGtfsTripRecord>(TRIPS_RESOURCE_ID, {
      limit: 1,
      filters: JSON.stringify({ route_id: routeId }),
    });

    if (!tripsResult.records || tripsResult.records.length === 0) {
      if (__DEV__) {
        console.warn(`[getLineStopsFromIbb] route_id=${routeId} için trip bulunamadı`);
      }
      return [];
    }

    const tripId = tripsResult.records[0].trip_id;

    // 2. Bu trip için stop_times kayıtlarını çek
    const stopTimesResult = await ckanDatastoreSearch<IbbGtfsStopTimeRecord>(
      STOP_TIMES_RESOURCE_ID,
      {
        limit: 500,
        filters: JSON.stringify({ trip_id: tripId }),
      }
    );

    if (!stopTimesResult.records || stopTimesResult.records.length === 0) {
      if (__DEV__) {
        console.warn(`[getLineStopsFromIbb] trip_id=${tripId} için stop_times bulunamadı`);
      }
      return [];
    }

    // 3. stop_sequence'e göre sırala (numeric değilse parseInt)
    const sortedStopTimes = stopTimesResult.records
      .map((st) => ({
        ...st,
        stop_sequence: typeof st.stop_sequence === 'string' ? parseInt(st.stop_sequence, 10) : st.stop_sequence,
      }))
      .sort((a, b) => {
        const seqA = typeof a.stop_sequence === 'number' ? a.stop_sequence : parseInt(String(a.stop_sequence), 10);
        const seqB = typeof b.stop_sequence === 'number' ? b.stop_sequence : parseInt(String(b.stop_sequence), 10);
        return seqA - seqB;
      });

    // 4. Tüm durakları al ve Map oluştur
    const allStops = await getAllStopsFromIbb();
    const stopMap = new Map<string, TransitStop>();
    allStops.forEach((stop) => {
      stopMap.set(stop.id, stop);
    });

    // 5. stop_times'daki stop_id'leri sırayla gez ve TransitStop'ları topla
    const lineStops: TransitStop[] = [];
    const seenStopIds = new Set<string>();

    for (const stopTime of sortedStopTimes) {
      const stopId = stopTime.stop_id;
      if (seenStopIds.has(stopId)) {
        continue; // Duplicate'leri atla
      }
      seenStopIds.add(stopId);

      const stop = stopMap.get(stopId);
      if (stop) {
        lineStops.push(stop);
      }
    }

    return lineStops;
  } catch (error) {
    // Kritik hatalar prod'da da loglanmalı
    console.error(`[getLineStopsFromIbb] route_id=${routeId} için hata:`, error);
    // Kullanıcıya patlamaması için boş dizi döndür
    return [];
  }
}

import { XMLParser } from 'fast-xml-parser';
import { iettConfig } from '../config/env';
// TransitLine, TransitStop, TransitMode already imported at top of file

const xmlParser = new XMLParser({ ignoreAttributes: false, trimValues: true });

// ============================================================================
// Types for raw IETT records
// ============================================================================

interface IettStopRecord {
  SDURAKKODU: string | number;  // Durak kodu (string veya number olabilir)
  SDURAKADI: string | number;   // Durak adı (string veya number olabilir)
  KOORDINAT: string; // "POINT (lon lat)"
  ILCEADI?: string;
  SYON?: string;
  AKILLI?: string;
  FIZIKI?: string;
  DURAK_TIPI?: string;
  ENGELLIKULLANIM?: string;
}

interface IettLineRecord {
  SHATKODU?: string | number;   // Hat Kodu (string veya number olabilir)
  SHATADI?: string | number;    // Hat Adı (string veya number olabilir)
  TARIFE?: string;
  HAT_UZUNLUGU?: string;
  SEFER_SURESI?: string;

  // İleride HatServisi_GYY veya başka kaynaklardan da kullanmak istersek diye
  HAT_KODU?: string | number;
  HATKODU?: string | number;
  HAT_ADI?: string | number;
  HATADI?: string | number;
  TAM_HAT_ADI?: string;
  TAMHATADI?: string;
}

// For DurakDetay_GYY XML
interface IettLineStopXmlRecord {
  HATKODU: string | number;
  YON: string;
  SIRANO: string;
  DURAKKODU: string | number;  // Durak kodu (string veya number olabilir)
  DURAKADI: string | number;   // Durak adı (string veya number olabilir)
  XKOORDINATI: string;
  YKOORDINATI: string;
  DURAKTIPI?: string;
  ISLETMEBOLGE?: string;
  ISLETMEALTBOLGE?: string;
  ILCEADI?: string;
}

// ============================================================================
// SOAP Helper Functions
// ============================================================================

/**
 * Generic SOAP call helper
 */
async function callSoap(
  endpoint: string,
  soapAction: string,
  bodyInnerXml: string,
  timeoutMs = 30000
): Promise<string> {
  const envelope = `<?xml version="1.0" encoding="utf-8"?>
<soap:Envelope xmlns:soap="http://schemas.xmlsoap.org/soap/envelope/"
               xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
               xmlns:xsd="http://www.w3.org/2001/XMLSchema">
  <soap:Body>
    ${bodyInnerXml}
  </soap:Body>
</soap:Envelope>`;

  const controller = new AbortController();
  const timeout = setTimeout(() => controller.abort(), timeoutMs);

  try {
    const res = await fetch(endpoint, {
      method: 'POST',
      headers: {
        'Content-Type': 'text/xml; charset=utf-8',
        'SOAPAction': `"${soapAction}"`, // SOAPAction değeri tırnak içinde olmalı (SOAP 1.1 standardı)
      },
      body: envelope,
      signal: controller.signal,
    });

    const text = await res.text();

    if (!res.ok) {
      // Kritik hatalar prod'da da loglanmalı
      console.error('[IETT SOAP] HTTP error', {
        endpoint,
        soapAction,
        status: res.status,
        statusText: res.statusText,
        body: text.substring(0, 500), // İlk 500 karakteri logla
      });
      throw new Error(`IETT SOAP HTTP ${res.status}: ${res.statusText}`);
    }

    // SOAP Fault kontrolü (HTTP 200 ama SOAP hatası olabilir)
    if (text.includes('soap:Fault') || text.includes('soapenv:Fault')) {
      // Kritik hatalar prod'da da loglanmalı
      console.error('[IETT SOAP] SOAP Fault detected', {
        endpoint,
        soapAction,
        faultBody: text.substring(0, 1000),
      });
      throw new Error('IETT SOAP Fault: API hatası döndü');
    }

    return text;
  } catch (error: any) {
    // Timeout kontrolü
    if (error.name === 'AbortError') {
      throw new Error(`IETT SOAP request timeout after ${timeoutMs}ms`);
    }
    
    // Network hatası
    if (error.message?.includes('fetch') || error.message?.includes('network')) {
      throw new Error(`IETT SOAP network error: ${error.message}`);
    }
    
    // Diğer hatalar
    throw error;
  } finally {
    clearTimeout(timeout);
  }
}

/**
 * Extract JSON string from SOAP *Result tag
 * 
 * SOAP Response yapısı:
 * <soap:Envelope>
 *   <soap:Body>
 *     <GetDurak_jsonResponse>
 *       <GetDurak_jsonResult>[...JSON string...]</GetDurak_jsonResult>
 *     </GetDurak_jsonResponse>
 *   </soap:Body>
 * </soap:Envelope>
 */
function extractSoapResultString(xml: string, resultTagName: string): string {
  try {
    const parsed = xmlParser.parse(xml);
    
    // Structure: Envelope > Body > {MethodName}Response > {ResultTag}
    const envelope = parsed['soap:Envelope'] ?? parsed.Envelope;
    if (!envelope) {
      if (__DEV__) {
        console.error('[IETT SOAP] XML parse error: missing Envelope', { xml: xml.substring(0, 500) });
      }
      throw new Error('Invalid SOAP XML: missing Envelope');
    }
    
    const body = envelope['soap:Body'] ?? envelope.Body;
    if (!body) {
      if (__DEV__) {
        console.error('[IETT SOAP] XML parse error: missing Body', { xml: xml.substring(0, 500) });
      }
      throw new Error('Invalid SOAP XML: missing Body');
    }

    // Response node'u bul (GetDurak_jsonResponse, GetHat_jsonResponse, vb.)
    const responseKey = Object.keys(body).find((k) => k.endsWith('Response'));
    if (!responseKey) {
      if (__DEV__) {
        console.error('[IETT SOAP] XML parse error: missing Response node', { 
        availableKeys: Object.keys(body),
        xml: xml.substring(0, 500) 
      });
      }
      throw new Error(`Invalid SOAP XML: missing *Response node. Available keys: ${Object.keys(body).join(', ')}`);
    }

    const response = body[responseKey];
    if (!response) {
      throw new Error(`Invalid SOAP XML: ${responseKey} is empty`);
    }

    // Result tag'ini bul
    const result = response[resultTagName];
    if (result === undefined || result === null) {
      if (__DEV__) {
        console.error('[IETT SOAP] XML parse error: result tag not found', {
        resultTagName,
        availableKeys: Object.keys(response),
        xml: xml.substring(0, 500)
      });
      }
      throw new Error(`SOAP result tag ${resultTagName} not found. Available keys: ${Object.keys(response).join(', ')}`);
    }

    if (typeof result !== 'string') {
      if (__DEV__) {
        console.error('[IETT SOAP] XML parse error: result is not a string', {
        resultTagName,
        resultType: typeof result,
        result: result
      });
      }
      throw new Error(`SOAP result tag ${resultTagName} is not a string (type: ${typeof result})`);
    }

    return result;
  } catch (error: any) {
    // Parsing hatası
    if (error.message.includes('Invalid SOAP XML') || error.message.includes('SOAP result tag')) {
      throw error;
    }
    // XML parser hatası
    if (__DEV__) {
      console.error('[IETT SOAP] XML parsing error', { error: error.message, xml: xml.substring(0, 500) });
    }
    throw new Error(`Failed to parse SOAP XML: ${error.message}`);
  }
}

/**
 * Parse IETT JSON array response
 * 
 * IETT API'si bazen direkt array, bazen object içinde array dönebilir.
 * Her iki durumu da handle ediyoruz.
 */
function parseIettJsonArray<T>(jsonText: string): T[] {
  const trimmed = jsonText.trim();
  if (!trimmed) {
    if (__DEV__) {
      console.warn('[IETT] Empty JSON response');
    }
    return [];
  }

  try {
    const data = JSON.parse(trimmed);
    
    // Direkt array ise
    if (Array.isArray(data)) {
      return data as T[];
    }

    // Object ise, içinde array property'si ara
    if (typeof data === 'object' && data !== null) {
      const arrKey = Object.keys(data).find((k) => Array.isArray(data[k]));
      if (arrKey) {
        return data[arrKey] as T[];
      }
      
      // Boş object ise
      if (Object.keys(data).length === 0) {
        if (__DEV__) {
          console.warn('[IETT] Empty object in JSON response');
        }
        return [];
      }
      
      // Beklenmeyen structure
      if (__DEV__) {
        console.error('[IETT] Unexpected JSON structure (object without array)', {
        keys: Object.keys(data),
        sample: JSON.stringify(data).substring(0, 200)
      });
      }
      throw new Error(`Unexpected IETT JSON structure: object without array property. Keys: ${Object.keys(data).join(', ')}`);
    }

    // Primitive değer
    if (__DEV__) {
      console.error('[IETT] Unexpected JSON structure (not array or object)', {
      type: typeof data,
      value: String(data).substring(0, 200)
    });
    }
    throw new Error(`Unexpected IETT JSON structure: expected array or object, got ${typeof data}`);
  } catch (error: any) {
    // JSON parse hatası
    if (error instanceof SyntaxError) {
      if (__DEV__) {
        console.error('[IETT] JSON parse error', {
        error: error.message,
        jsonText: jsonText.substring(0, 500)
      });
      }
      throw new Error(`Failed to parse IETT JSON: ${error.message}`);
    }
    // Diğer hatalar
    throw error;
  }
}

/**
 * Parse "POINT (lon lat)" coordinate string
 */
function parsePoint(point: string): { lon: number; lat: number } | null {
  if (!point) return null;
  // Example: "POINT (29.0209720086216 41.1085509961235)"
  const match = point.match(/POINT\s*\(\s*([0-9\.\-]+)\s+([0-9\.\-]+)\s*\)/i);
  if (!match) return null;

  const lon = Number(match[1]);
  const lat = Number(match[2]);
  if (!Number.isFinite(lat) || !Number.isFinite(lon)) return null;

  return { lat, lon };
}

// ============================================================================
// Mapping Functions
// ============================================================================

/**
 * Map IETT stop record to TransitStop DTO
 */
function mapIettStopToTransitStop(rec: IettStopRecord): TransitStop {
  const coords = parsePoint(rec.KOORDINAT);
  if (!coords) {
    throw new Error(`Invalid KOORDINAT for stop ${rec.SDURAKKODU}: ${rec.KOORDINAT}`);
  }

  const id = String(rec.SDURAKKODU);
  const name = String(rec.SDURAKADI);

  return {
    id,
    code: id,
    name,
    latitude: coords.lat,
    longitude: coords.lon,
    modes: ['BUS'] as TransitMode[],
    lineIds: [],
  };
}

/**
 * Map IETT line record to TransitLine DTO
 */
function mapIettLineToTransitLine(rec: IettLineRecord): TransitLine {
  // Önce SHATKODU'nu kullan, yoksa HAT_KODU / HATKODU'na düş
  const rawCode =
    rec.SHATKODU ??
    rec.HAT_KODU ??
    rec.HATKODU;

  // rawCode undefined/null/boş string ise hata, ama 0 (number) geçerli olabilir
  if (rawCode === undefined || rawCode === null || rawCode === '') {
    if (__DEV__) {
      console.error('[IETT] Line record has no id-like field', rec);
    }
    throw new Error('IETT line record missing SHATKODU/HAT_KODU/HATKODU');
  }

  const code = String(rawCode);

  const rawName =
    rec.SHATADI ??
    rec.HAT_ADI ??
    rec.HATADI ??
    rawCode;

  const name = String(rawName);

  return {
    id: code,      // TransitLine.id
    code,          // TransitLine.code
    name,          // TransitLine.name
    mode: 'BUS',   // IETT hatları için default BUS
  };
}

// ============================================================================
// In-Memory Caches
// ============================================================================

let cachedStops: TransitStop[] | null = null;
let cachedStopsFetchedAt: number | null = null;

let cachedLines: TransitLine[] | null = null;
let cachedLinesFetchedAt: number | null = null;

// 6 hours default cache
const STOPS_CACHE_TTL_MS = 6 * 60 * 60 * 1000;
const LINES_CACHE_TTL_MS = 6 * 60 * 60 * 1000;

// ============================================================================
// Public Functions - Stops
// ============================================================================

/**
 * Get all stops from IETT (with caching)
 */
export async function getAllStopsFromIett(): Promise<TransitStop[]> {
  const now = Date.now();
  if (
    cachedStops &&
    cachedStopsFetchedAt &&
    now - cachedStopsFetchedAt < STOPS_CACHE_TTL_MS
  ) {
    return cachedStops;
  }

  try {
    // Dokümana göre: DurakKodu parametresi boş girilirse tüm durak listesini döndürür
    // Web Servis Adresi: https://api.ibb.gov.tr/iett/UlasimAnaVeri/HatDurakGuzergah.asmx
    const xml = await callSoap(
      iettConfig.hatDurakEndpoint,
      'http://tempuri.org/GetDurak_json',
      `<GetDurak_json xmlns="http://tempuri.org/">
       <DurakKodu></DurakKodu>
     </GetDurak_json>`
    );

    const jsonText = extractSoapResultString(xml, 'GetDurak_jsonResult');
    const rawStops = parseIettJsonArray<IettStopRecord>(jsonText);

    if (rawStops.length === 0) {
      if (__DEV__) {
        console.warn('[IETT] getAllStopsFromIett returned empty array');
      }
    }

    const stops = rawStops.map((rec, index) => {
      try {
        return mapIettStopToTransitStop(rec);
      } catch (error: any) {
        // Kritik hatalar prod'da da loglanmalı
        console.error(`[IETT] Error mapping stop at index ${index}`, {
          record: rec,
          error: error.message
        });
        // Invalid record'u skip et, devam et
        return null;
      }
    }).filter((stop): stop is TransitStop => stop !== null);

    if (stops.length === 0 && rawStops.length > 0) {
      throw new Error('All stop records failed to map. Check coordinate format.');
    }

    cachedStops = stops;
    cachedStopsFetchedAt = now;
    if (__DEV__) {
      console.log(`[IETT] Loaded ${stops.length} stops (${rawStops.length} raw records)`);
    }
    return stops;
  } catch (error: any) {
    // Kritik hatalar prod'da da loglanmalı
    console.error('[IETT] getAllStopsFromIett failed', {
      endpoint: iettConfig.hatDurakEndpoint,
      error: error.message
    });
    throw error;
  }
}

/**
 * Search stops by name or code
 */
export async function searchStopsByNameOrCode(
  query: string,
  limit = 25
): Promise<TransitStop[]> {
  const trimmed = query.trim().toLocaleLowerCase('tr-TR');
  if (!trimmed) return [];

  const stops = await getAllStopsFromIett();
  
  // Debug: İlk 10 durağın isimlerini logla (sadece ilk aramada)
  if (!(global as any)._debugStopsLogged) {
    if (__DEV__) {
      console.log('[DEBUG] Sample stop names:', stops.slice(0, 10).map(s => s.name));
    }
    (global as any)._debugStopsLogged = true;
  }
  
  // 1. Önce exact match ara (code veya name içinde query geçiyor mu)
  let results = stops.filter((s) => {
    const code = (s.code ?? '').toString().toLocaleLowerCase('tr-TR');
    const name = (s.name ?? '').toString().toLocaleLowerCase('tr-TR');
    return code.includes(trimmed) || name.includes(trimmed);
  });

  // 2. Eğer sonuç yoksa ve query en az 3 karakter ise, başlangıç eşleşmesi ara
  // Örnek: "avci" -> "avcilar" bulunmalı (başlangıçta "avci" geçiyor)
  if (results.length === 0 && trimmed.length >= 3) {
    results = stops.filter((s) => {
      const code = (s.code ?? '').toString().toLocaleLowerCase('tr-TR');
      const name = (s.name ?? '').toString().toLocaleLowerCase('tr-TR');
      // Query durağın isminin veya kodunun başlangıcında mı?
      return name.startsWith(trimmed) || code.startsWith(trimmed);
    });
  }

  // 3. Hala sonuç yoksa, partial match ara (query'nin ilk 3 karakteri ile)
  if (results.length === 0 && trimmed.length >= 3) {
    const prefix = trimmed.substring(0, 3);
    results = stops.filter((s) => {
      const code = (s.code ?? '').toString().toLocaleLowerCase('tr-TR');
      const name = (s.name ?? '').toString().toLocaleLowerCase('tr-TR');
      return name.includes(prefix) || code.includes(prefix);
    });
  }

  if (__DEV__) {
    console.log(`[IETT] searchStopsByNameOrCode: query="${query}" -> "${trimmed}" found ${results.length} stops (total: ${stops.length})`);
  }

  return results.slice(0, limit);
}

/**
 * Get stop by ID
 */
export async function getStopByIdFromIett(stopId: string): Promise<TransitStop | null> {
  const stops = await getAllStopsFromIett();
  return stops.find((s) => s.id === stopId) ?? null;
}

// ============================================================================
// Public Functions - Lines
// ============================================================================

/**
 * Get all lines from IETT (with caching)
 */
export async function getAllLinesFromIett(): Promise<TransitLine[]> {
  const now = Date.now();
  if (
    cachedLines &&
    cachedLinesFetchedAt &&
    now - cachedLinesFetchedAt < LINES_CACHE_TTL_MS
  ) {
    return cachedLines;
  }

  try {
    // Dokümana göre: HatKodu parametresi boş girilirse tüm hat listesini döndürür
    // Web Servis Adresi: https://api.ibb.gov.tr/iett/UlasimAnaVeri/HatDurakGuzergah.asmx
    const xml = await callSoap(
      iettConfig.hatDurakEndpoint,
      'http://tempuri.org/GetHat_json',
      `<GetHat_json xmlns="http://tempuri.org/">
       <HatKodu></HatKodu>
     </GetHat_json>`
    );

    const jsonText = extractSoapResultString(xml, 'GetHat_jsonResult');
    const rawLines = parseIettJsonArray<IettLineRecord>(jsonText);

    if (rawLines.length === 0) {
      if (__DEV__) {
        console.warn('[IETT] getAllLinesFromIett returned empty array');
      }
    }

    const lines = rawLines.map((rec, index) => {
      try {
        return mapIettLineToTransitLine(rec);
      } catch (error: any) {
        // Kritik hatalar prod'da da loglanmalı
        console.error(`[IETT] Error mapping line at index ${index}`, {
          record: rec,
          error: error.message
        });
        // Invalid record'u skip et, devam et
        return null;
      }
    }).filter((line): line is TransitLine => line !== null);

    if (lines.length === 0 && rawLines.length > 0) {
      throw new Error('All line records failed to map. Check line code/name format.');
    }

    cachedLines = lines;
    cachedLinesFetchedAt = now;
    if (__DEV__) {
      console.log(`[IETT] Loaded ${lines.length} lines (${rawLines.length} raw records)`);
    }
    return lines;
  } catch (error: any) {
    // Kritik hatalar prod'da da loglanmalı
    console.error('[IETT] getAllLinesFromIett failed', {
      endpoint: iettConfig.hatDurakEndpoint,
      error: error.message
    });
    throw error;
  }
}

/**
 * Search lines by query
 */
export async function searchLinesByQuery(
  query: string,
  limit = 50
): Promise<TransitLine[]> {
  const trimmed = query.trim().toLocaleLowerCase('tr-TR');
  const lines = await getAllLinesFromIett();

  if (!trimmed) {
    return lines.slice(0, limit);
  }

  const results = lines.filter((l) => {
    const code = (l.code ?? '').toString().toLocaleLowerCase('tr-TR');
    const name = (l.name ?? '').toString().toLocaleLowerCase('tr-TR');
    return code.includes(trimmed) || name.includes(trimmed);
  });

  if (__DEV__) {
    console.log(`[IETT] searchLinesByQuery: query="${query}" -> "${trimmed}" found ${results.length} lines (total: ${lines.length})`);
  }

  return results.slice(0, limit);
}

// ============================================================================
// Public Functions - Line Stops (DurakDetay_GYY)
// ============================================================================

/**
 * Parse DurakDetay_GYY XML response
 * 
 * API Response Structure (from documentation and SOAP UI tests):
 * <soap:Envelope>
 *   <soap:Body>
 *     <DurakDetay_GYYResponse>
 *       <DurakDetay_GYYResult>
 *         <NewDataSet>
 *           <Table>
 *             <HATKODU>760</HATKODU>
 *             <YON>D</YON>
 *             <SIRANO>1</SIRANO>
 *             <DURAKKODU>302461</DURAKKODU>
 *             ...
 *           </Table>
 *           <Table>...</Table>
 *         </NewDataSet>
 *       </DurakDetay_GYYResult>
 *     </DurakDetay_GYYResponse>
 *   </soap:Body>
 * </soap:Envelope>
 */
function parseDurakDetayXml(xml: string): IettLineStopXmlRecord[] {
  try {
  const parsed = xmlParser.parse(xml);
  const envelope = parsed['soap:Envelope'] ?? parsed.Envelope;
    if (!envelope) {
      if (__DEV__) {
        console.error('[IETT] parseDurakDetayXml: Missing Envelope', { xml: xml.substring(0, 500) });
      }
      return [];
    }
    
    const body = envelope['soap:Body'] ?? envelope.Body;
    if (!body) {
      if (__DEV__) {
        console.error('[IETT] parseDurakDetayXml: Missing Body', { xml: xml.substring(0, 500) });
      }
      return [];
    }
    
  const responseKey = Object.keys(body).find((k) => k.endsWith('Response'));
    if (!responseKey) {
      if (__DEV__) {
        console.error('[IETT] parseDurakDetayXml: Missing Response node', { 
        availableKeys: Object.keys(body),
        xml: xml.substring(0, 500) 
      });
      }
      return [];
    }
    
  const response = body[responseKey];
  const result = response['DurakDetay_GYYResult'];
    if (!result) {
      if (__DEV__) {
        console.warn('[IETT] parseDurakDetayXml: Missing DurakDetay_GYYResult', {
        responseKeys: Object.keys(response),
        xml: xml.substring(0, 500)
      });
      }
      return [];
    }

    // API dokümantasyonuna göre: NewDataSet > Table array
    // Önce NewDataSet'i kontrol et
    if (result.NewDataSet) {
      const tables = result.NewDataSet.Table;
      if (!tables) {
        if (__DEV__) {
          console.warn('[IETT] parseDurakDetayXml: NewDataSet exists but no Table found');
        }
        return [];
      }
      if (Array.isArray(tables)) {
        if (__DEV__) {
          console.log(`[IETT] parseDurakDetayXml: Found ${tables.length} records in NewDataSet.Table array`);
        }
        return tables as IettLineStopXmlRecord[];
      }
      // Tek bir Table varsa array'e çevir
      if (__DEV__) {
        console.log('[IETT] parseDurakDetayXml: Found single Table in NewDataSet');
      }
      return [tables as IettLineStopXmlRecord];
    }

    // Eski format desteği (backward compatibility)
    // Eğer direkt DurakDetay_GYY array'i varsa onu kullan
    if (result.DurakDetay_GYY) {
  const records = result.DurakDetay_GYY;
      if (Array.isArray(records)) {
        if (__DEV__) {
          console.log(`[IETT] parseDurakDetayXml: Found ${records.length} records in DurakDetay_GYY array (legacy format)`);
        }
        return records as IettLineStopXmlRecord[];
      }
      if (__DEV__) {
        console.log('[IETT] parseDurakDetayXml: Found single record in DurakDetay_GYY (legacy format)');
      }
  return [records as IettLineStopXmlRecord];
    }

    // Hiçbir format bulunamadı
    if (__DEV__) {
      console.warn('[IETT] parseDurakDetayXml: No records found. Result structure:', {
      resultKeys: Object.keys(result),
      sampleResult: JSON.stringify(result).substring(0, 500)
    });
    }
    return [];
  } catch (error: any) {
    if (__DEV__) {
      console.error('[IETT] parseDurakDetayXml: Parse error', {
      error: error.message,
      xml: xml.substring(0, 500)
    });
    }
    return [];
  }
}

/**
 * Get ordered stops for a line (with direction preference)
 */
export async function getLineStopsFromIett(lineId: string): Promise<{
  line: TransitLine | null;
  stops: TransitStop[];
}> {
  if (!lineId || lineId.trim().length === 0) {
    throw new Error('Line ID is required');
  }

  try {
    // Önce hat listesinden gerçek hat kodunu bul
    const allLines = await getAllLinesFromIett();
    const normalizedLineId = lineId.trim().toUpperCase();
    
    // Debug: Hat listesinde arama yapılan hat kodunu logla
    const similarLines = allLines.filter((l) => {
      const lineCode = String(l.code ?? '').toUpperCase().trim();
      const lineId = String(l.id ?? '').toUpperCase().trim();
      return lineCode.includes(normalizedLineId) || normalizedLineId.includes(lineCode) ||
             lineId.includes(normalizedLineId) || normalizedLineId.includes(lineId);
    }).slice(0, 5); // İlk 5 benzer hattı göster
    
    if (similarLines.length > 0) {
      if (__DEV__) {
        console.log(`[IETT] getLineStopsFromIett: Similar lines found for "${lineId}":`, 
        similarLines.map(l => ({ code: l.code, id: l.id, name: l.name }))
      );
      }
    }
    
    // Hat listesinden eşleşen hattı bul (TAM EŞLEŞME - includes kullanma!)
    // Önce tam eşleşme dene, sonra normalize edilmiş versiyonları dene
    const matchedLine = allLines.find((l) => {
      const lineIdUpper = String(l.id ?? '').toUpperCase().trim();
      const lineCodeUpper = String(l.code ?? '').toUpperCase().trim();
      
      // Tam eşleşme kontrolü (öncelikli)
      if (lineIdUpper === normalizedLineId || lineCodeUpper === normalizedLineId) {
        return true;
      }
      
      // Normalize edilmiş versiyonları kontrol et (boşluk, tire vb. temizle)
      const normalizedLineIdClean = normalizedLineId.replace(/[\s\-_]/g, '');
      const lineIdClean = lineIdUpper.replace(/[\s\-_]/g, '');
      const lineCodeClean = lineCodeUpper.replace(/[\s\-_]/g, '');
      
      if (lineIdClean === normalizedLineIdClean || lineCodeClean === normalizedLineIdClean) {
        return true;
      }
      
      return false;
    });
    
    // Gerçek hat kodunu kullan (API'den gelen format)
    // Önce code'u dene, yoksa id'yi kullan, yoksa orijinal değeri kullan
    let realLineCode: string;
    if (matchedLine) {
      // API'den gelen gerçek hat kodunu kullan
      realLineCode = String(matchedLine.code ?? matchedLine.id ?? normalizedLineId).trim().toUpperCase();
      if (__DEV__) {
        console.log(`[IETT] getLineStopsFromIett: Found matching line "${matchedLine.name}" with code "${realLineCode}" for query "${lineId}"`);
      }
    } else {
      // Eşleşme bulunamadı, orijinal değeri kullan
      realLineCode = normalizedLineId;
      if (__DEV__) {
        console.log(`[IETT] getLineStopsFromIett: No matching line found for "${lineId}", using original value`);
      }
    }
    
    if (__DEV__) {
      console.log(`[IETT] getLineStopsFromIett: Requesting stops for line "${lineId}" (using code: "${realLineCode}")`);
    }
    
    // Denenecek hat kodu varyasyonları - gerçek hat kodunu önce dene
    const variations: string[] = [realLineCode];
    
    // Orijinal normalized değeri de ekle (eğer farklıysa ve eşleşme bulunduysa)
    if (matchedLine && normalizedLineId !== realLineCode) {
      variations.push(normalizedLineId);
    }
    
    // Eğer hat kodu harf içeriyorsa, sadece sayı kısmını dene
    if (/[A-Z]/.test(realLineCode)) {
      const numericOnly = realLineCode.replace(/[^0-9]/g, '');
      if (numericOnly && numericOnly !== realLineCode) {
        variations.push(numericOnly);
      }
    }
    
    // Eğer hat kodu sadece sayı ise, padding ile dene (örn: "401" -> "0401")
    if (/^\d+$/.test(realLineCode)) {
      const padded = realLineCode.padStart(4, '0');
      if (padded !== realLineCode) {
        variations.push(padded);
      }
    }
    
    // Eğer hat kodu sayı + harf formatındaysa, farklı kombinasyonlar dene
    // Örnek: "11C" -> ["11C", "11", "011C", "011", "0011C", "0011", "011C"]
    const match = realLineCode.match(/^(\d+)([A-Z]+)$/);
    if (match) {
      const [, numPart, letterPart] = match;
      variations.push(numPart); // Sadece sayı
      
      // Farklı padding uzunlukları dene
      if (numPart.length === 1) {
        // 1 haneli: "1C" -> ["1C", "01C", "001C", "0001C"]
        variations.push(numPart.padStart(2, '0') + letterPart);
        variations.push(numPart.padStart(3, '0') + letterPart);
        variations.push(numPart.padStart(4, '0') + letterPart);
        variations.push(numPart.padStart(2, '0'));
        variations.push(numPart.padStart(3, '0'));
        variations.push(numPart.padStart(4, '0'));
      } else if (numPart.length === 2) {
        // 2 haneli: "11C" -> ["11C", "011C", "0011C"]
        variations.push(numPart.padStart(3, '0') + letterPart);
        variations.push(numPart.padStart(4, '0') + letterPart);
        variations.push(numPart.padStart(3, '0'));
        variations.push(numPart.padStart(4, '0'));
      } else if (numPart.length === 3) {
        // 3 haneli: "401C" -> ["401C", "0401C"]
        variations.push(numPart.padStart(4, '0') + letterPart);
        variations.push(numPart.padStart(4, '0'));
      }
    }
    
    // Tekrarları kaldır ve sırala (gerçek hat kodunu önce dene)
    const uniqueVariations = Array.from(new Set(variations));
    if (__DEV__) {
      console.log(`[IETT] getLineStopsFromIett: Will try ${uniqueVariations.length} variations:`, uniqueVariations);
    }
    
    let rawRecords: any[] = [];
    let successfulVariation: string | null = null;
    
    // Her varyasyonu dene
    for (const variation of uniqueVariations) {
      try {
        if (__DEV__) {
          console.log(`[IETT] getLineStopsFromIett: Trying variation "${variation}" for line "${lineId}"`);
        }
        const xml = await callSoap(
          iettConfig.ibbEndpoint,
          'http://tempuri.org/DurakDetay_GYY',
          `<DurakDetay_GYY xmlns="http://tempuri.org/">
           <hat_kodu>${variation}</hat_kodu>
         </DurakDetay_GYY>`
        );
        
        // Debug: İlk denemede XML'in bir kısmını logla
        if (variation === uniqueVariations[0]) {
          if (__DEV__) {
            console.log(`[IETT] getLineStopsFromIett: First variation XML response (first 1000 chars):`, xml.substring(0, 1000));
          }
        }
        
        const records = parseDurakDetayXml(xml);
        if (__DEV__) {
          console.log(`[IETT] getLineStopsFromIett: Variation "${variation}" returned ${records.length} records`);
        }
        
        // Eğer kayıt varsa, ilk kayıttaki HATKODU'yu kontrol et
        if (records.length > 0) {
          const firstRecord = records[0];
          const recordHatKodu = firstRecord.HATKODU ? String(firstRecord.HATKODU).trim().toUpperCase() : null;
          if (__DEV__) {
            console.log(`[IETT] getLineStopsFromIett: First record HATKODU: "${recordHatKodu}" (requested: "${variation}")`);
          }
          
          rawRecords = records;
          successfulVariation = variation;
          if (__DEV__) {
            console.log(`[IETT] getLineStopsFromIett: ✅ Found ${records.length} stops using variation "${variation}"`);
          }
          break;
        } else {
          if (__DEV__) {
            console.log(`[IETT] getLineStopsFromIett: Variation "${variation}" returned empty result`);
          }
        }
      } catch (error: any) {
        if (__DEV__) {
          console.warn(`[IETT] getLineStopsFromIett: Variation "${variation}" failed:`, error.message);
        }
        // Bir sonraki varyasyonu dene
        continue;
      }
    }
    
    if (!rawRecords.length) {
      if (__DEV__) {
        console.warn(`[IETT] getLineStopsFromIett: No stops found for line ${lineId} after trying ${uniqueVariations.length} variations`);
      }
      return { line: matchedLine ?? null, stops: [] };
    }

    // Choose direction: prefer "G" (gidiş), otherwise first available direction
    const directions = Array.from(new Set(rawRecords.map((r) => r.YON).filter(Boolean)));
    if (directions.length === 0) {
      if (__DEV__) {
        console.warn(`[IETT] getLineStopsFromIett: No direction found for line ${lineId}`);
      }
      return { line: null, stops: [] };
    }

    const chosenDir = directions.includes('G') ? 'G' : directions[0];
    const filtered = rawRecords.filter((r) => r.YON === chosenDir);

    // Sort by SIRANO
    filtered.sort((a, b) => {
      const orderA = Number(a.SIRANO);
      const orderB = Number(b.SIRANO);
      if (Number.isNaN(orderA) || Number.isNaN(orderB)) {
        return 0; // Invalid order, keep original order
      }
      return orderA - orderB;
    });

    const stops: TransitStop[] = filtered.map((rec, index) => {
      try {
        const id = String(rec.DURAKKODU ?? '');
        const name = String(rec.DURAKADI ?? '');
        const latitude = Number(rec.YKOORDINATI);
        const longitude = Number(rec.XKOORDINATI);

        if (!id || !name) {
          throw new Error('Missing stop ID or name');
        }

        if (!Number.isFinite(latitude) || !Number.isFinite(longitude)) {
          throw new Error(`Invalid coordinates: lat=${rec.YKOORDINATI}, lon=${rec.XKOORDINATI}`);
        }

        return {
          id,
          code: id,
          name,
          latitude,
          longitude,
          modes: ['BUS'] as TransitMode[],
          lineIds: [lineId],
        };
      } catch (error: any) {
        // Kritik hatalar prod'da da loglanmalı
        console.error(`[IETT] Error mapping line stop at index ${index}`, {
          record: rec,
          error: error.message
        });
        return null;
      }
    }).filter((stop): stop is TransitStop => stop !== null);

    if (stops.length === 0 && filtered.length > 0) {
      throw new Error(`All stops for line ${lineId} failed to map. Check coordinate format.`);
    }

    // Hat bilgisini zaten yukarıda bulduk, tekrar aramaya gerek yok
    const line = matchedLine ?? null;

    if (__DEV__) {
      console.log(`[IETT] getLineStopsFromIett: Found ${stops.length} stops for line ${lineId} (direction: ${chosenDir}, used variation: ${successfulVariation})`);
    }
    return { line, stops };
  } catch (error: any) {
    // Kritik hatalar prod'da da loglanmalı
    console.error('[IETT] getLineStopsFromIett failed', {
      lineId,
      endpoint: iettConfig.ibbEndpoint,
      error: error.message
    });
    throw error;
  }
}

/**
 * NOTE:
 * - This client maps IETT web service responses to our core types:
 *   - TransitLine: { id, code, name, mode }
 *   - TransitStop: { id, code, name, latitude, longitude, modes, lineIds }
 * - Line data comes from GetHat_json (SHATKODU / SHATADI).
 * - Stop data comes from GetDurak_json (SDURAKKODU / SDURAKADI / KOORDINAT).
 * - Line-stop relations come from DurakDetay_GYY (HATKODU / YON / SIRANO / DURAKKODU).
 */

import {
  ULS_CKAN_BASE_URL,
  ULS_ROUTES_RESOURCE_ID,
  ULS_TRIPS_RESOURCE_ID,
  ULS_STOPS_RESOURCE_ID,
  ULS_STOP_TIMES_RESOURCE_ID,
} from '../config/env';
// TransitLine, TransitMode, TransitStop already imported at top of file
// haversineDistanceMeters already imported at top of file
import { cache } from '../utils/cache';

// ============================================================================
// TYPES
// ============================================================================

interface CkanSqlResponse<T> {
  success: boolean;
  result?: {
    records: T[];
    fields: Array<{ type: string; id: string }>;
  };
  error?: {
    message: string;
    __type: string;
  };
}

// GTFS raw record types
interface GtfsRouteRecord {
  route_id: string;
  route_short_name?: string;
  route_long_name?: string;
  route_desc?: string;
  route_type?: number | string;
  route_color?: string;
  agency_id?: string;
  [key: string]: any;
}

interface GtfsTripRecord {
  trip_id: string;
  route_id: string;
  direction_id?: number | string;
  trip_headsign?: string;
  service_id?: string;
  [key: string]: any;
}

interface GtfsStopRecord {
  stop_id: string;
  stop_name: string;
  stop_lat: number | string;
  stop_lon: number | string;
  stop_code?: string;
  [key: string]: any;
}

interface GtfsStopTimeRecord {
  trip_id: string;
  stop_id: string;
  stop_sequence: number | string;
  arrival_time?: string;
  departure_time?: string;
  [key: string]: any;
}

export interface TripSummary {
  trip_id: string;
  route_id: string;
  direction_id: number;
  trip_headsign?: string;
}

export interface StopTimeRecord {
  trip_id: string;
  stop_id: string;
  stop_sequence: number;
  arrival_time?: string;
  departure_time?: string;
}

// ============================================================================
// LOW-LEVEL CKAN SQL QUERY HELPER
// ============================================================================

/**
 * CKAN Data API SQL query helper
 * datastore_search_sql endpoint'ini kullanır
 */
async function ckanSqlQuery<T>(
  resourceId: string,
  sql: string,
  params?: Record<string, any>
): Promise<T[]> {
  const url = new URL(`${ULS_CKAN_BASE_URL}/datastore_search_sql`);

  // SQL query'yi parametre olarak ekle
  url.searchParams.set('sql', sql);

  // Eğer params varsa, SQL query içinde kullanılmak üzere hazırlanmalı
  // CKAN SQL API genellikle direkt SQL string kabul eder, parametre binding yok
  // Bu yüzden SQL injection'a karşı dikkatli olmalıyız

  try {
    const response = await fetch(url.toString());

    if (!response.ok) {
      throw new Error(`CKAN SQL query failed with status ${response.status}`);
    }

    const jsonUnknown: unknown = await response.json();
    const json = (jsonUnknown && typeof jsonUnknown === 'object') 
      ? (jsonUnknown as CkanSqlResponse<T>) 
      : ({ success: false, result: { records: [], fields: [] } } as unknown as CkanSqlResponse<T>);

    if (!json.success) {
      const errorMsg = json.error?.message || 'Unknown CKAN error';
      throw new Error(`CKAN SQL error: ${errorMsg}`);
    }

    if (!json.result || !json.result.records) {
      return [];
    }

    return json.result.records;
  } catch (error) {
    // Kritik hatalar prod'da da loglanmalı
    console.error(`[ckanSqlQuery] Error querying resource ${resourceId}:`, error);
    throw error;
  }
}

/**
 * SQL injection'a karşı güvenli string escape
 * Basit bir helper, sadece basit string değerler için kullanılmalı
 */
function escapeSqlString(value: string): string {
  // Single quote'ları double single quote ile escape et
  return value.replace(/'/g, "''");
}

// ============================================================================
// ROUTE TYPE TO MODE MAPPING
// ============================================================================

// mapRouteTypeToMode already defined at line 111, using that function

// ============================================================================
// ROUTES (LINES)
// ============================================================================

/**
 * Tüm route'ları (hatları) getir
 */
export async function getAllRoutes(): Promise<TransitLine[]> {
  if (!ULS_ROUTES_RESOURCE_ID) {
    throw new Error('ULS_ROUTES_RESOURCE_ID tanımlı değil');
  }

  // Cache kontrolü
  const cacheKey = 'routes:all';
  const cached = cache.get<TransitLine[]>(cacheKey);
  if (cached) {
    return cached;
  }

  const sql = `SELECT * FROM "${ULS_ROUTES_RESOURCE_ID}"`;
  const records = await ckanSqlQuery<GtfsRouteRecord>(ULS_ROUTES_RESOURCE_ID, sql);

  const mapped: TransitLine[] = records.map((rec) => {
    const routeType = typeof rec.route_type === 'string' 
      ? parseInt(rec.route_type, 10) 
      : (rec.route_type ?? 3); // Default: BUS

    return {
      id: rec.route_id,
      code: rec.route_short_name || rec.route_id,
      name: rec.route_long_name || rec.route_short_name || rec.route_id,
      mode: mapRouteTypeToMode(routeType),
    };
  });

  // 1 saat cache
  cache.set(cacheKey, mapped, 60 * 60 * 1000);
  return mapped;
}

/**
 * Query ile route arama
 */
export async function searchRoutesByQuery(query: string): Promise<TransitLine[]> {
  if (!ULS_ROUTES_RESOURCE_ID) {
    return [];
  }

  const trimmed = query.trim();
  if (!trimmed || trimmed.length < 1) {
    return [];
  }

  // SQL injection koruması için query'yi escape et
  const escapedQuery = escapeSqlString(trimmed);
  
  // Numeric query ise route_short_name'de arama yap
  // Ayrıca route_long_name'de de arama yap
  const sql = `
    SELECT * FROM "${ULS_ROUTES_RESOURCE_ID}"
    WHERE 
      route_short_name ILIKE '%${escapedQuery}%'
      OR route_long_name ILIKE '%${escapedQuery}%'
    LIMIT 50
  `;

  try {
    const records = await ckanSqlQuery<GtfsRouteRecord>(ULS_ROUTES_RESOURCE_ID, sql);

    return records.map((rec) => {
      const routeType = typeof rec.route_type === 'string' 
        ? parseInt(rec.route_type, 10) 
        : (rec.route_type ?? 3);

      return {
        id: rec.route_id,
        code: rec.route_short_name || rec.route_id,
        name: rec.route_long_name || rec.route_short_name || rec.route_id,
        mode: mapRouteTypeToMode(routeType),
      };
    });
  } catch (error) {
    // Kritik hatalar prod'da da loglanmalı
    console.error('[searchRoutesByQuery] Error:', error);
    return [];
  }
}

// ============================================================================
// TRIPS
// ============================================================================

/**
 * Belirli bir route için trip'leri getir
 * direction_id = 0 olan trip'i tercih eder (genellikle gidiş yönü)
 */
export async function getTripsByRoute(routeId: string): Promise<TripSummary[]> {
  if (!ULS_TRIPS_RESOURCE_ID) {
    throw new Error('ULS_TRIPS_RESOURCE_ID tanımlı değil');
  }

  const escapedRouteId = escapeSqlString(routeId);
  const sql = `
    SELECT * FROM "${ULS_TRIPS_RESOURCE_ID}"
    WHERE route_id = '${escapedRouteId}'
    ORDER BY direction_id ASC
    LIMIT 10
  `;

  try {
    const records = await ckanSqlQuery<GtfsTripRecord>(ULS_TRIPS_RESOURCE_ID, sql);

    return records.map((rec) => ({
      trip_id: rec.trip_id,
      route_id: rec.route_id,
      direction_id: typeof rec.direction_id === 'string'
        ? parseInt(rec.direction_id, 10)
        : (rec.direction_id ?? 0),
      trip_headsign: rec.trip_headsign,
    }));
  } catch (error) {
    // Kritik hatalar prod'da da loglanmalı
    console.error(`[getTripsByRoute] Error for route ${routeId}:`, error);
    return [];
  }
}

// ============================================================================
// STOP TIMES
// ============================================================================

/**
 * Belirli bir trip için stop_times kayıtlarını getir
 * stop_sequence'e göre sıralı döner
 */
export async function getStopTimesByTrip(tripId: string): Promise<StopTimeRecord[]> {
  if (!ULS_STOP_TIMES_RESOURCE_ID) {
    throw new Error('ULS_STOP_TIMES_RESOURCE_ID tanımlı değil');
  }

  const escapedTripId = escapeSqlString(tripId);
  const sql = `
    SELECT * FROM "${ULS_STOP_TIMES_RESOURCE_ID}"
    WHERE trip_id = '${escapedTripId}'
    ORDER BY stop_sequence ASC
  `;

  try {
    const records = await ckanSqlQuery<GtfsStopTimeRecord>(
      ULS_STOP_TIMES_RESOURCE_ID,
      sql
    );

    return records.map((rec) => ({
      trip_id: rec.trip_id,
      stop_id: rec.stop_id,
      stop_sequence: typeof rec.stop_sequence === 'string'
        ? parseInt(rec.stop_sequence, 10)
        : (rec.stop_sequence ?? 0),
      arrival_time: rec.arrival_time,
      departure_time: rec.departure_time,
    }));
  } catch (error) {
    // Kritik hatalar prod'da da loglanmalı
    console.error(`[getStopTimesByTrip] Error for trip ${tripId}:`, error);
    return [];
  }
}

// ============================================================================
// STOPS
// ============================================================================

/**
 * Belirli stop ID'leri için stop detaylarını getir
 * Map olarak döner (key: stop_id, value: TransitStop)
 */
export async function getStopsByIds(stopIds: string[]): Promise<Map<string, TransitStop>> {
  if (!ULS_STOPS_RESOURCE_ID || stopIds.length === 0) {
    return new Map();
  }

  // SQL IN clause için stop ID'leri escape et ve birleştir
  const escapedIds = stopIds.map((id) => `'${escapeSqlString(id)}'`).join(',');
  
  const sql = `
    SELECT * FROM "${ULS_STOPS_RESOURCE_ID}"
    WHERE stop_id IN (${escapedIds})
  `;

  try {
    const records = await ckanSqlQuery<GtfsStopRecord>(ULS_STOPS_RESOURCE_ID, sql);

    const stopsMap = new Map<string, TransitStop>();

    records.forEach((rec) => {
      const lat = typeof rec.stop_lat === 'string' ? parseFloat(rec.stop_lat) : rec.stop_lat;
      const lon = typeof rec.stop_lon === 'string' ? parseFloat(rec.stop_lon) : rec.stop_lon;

      if (isNaN(lat) || isNaN(lon)) {
        if (__DEV__) {
          console.warn(`[getStopsByIds] Invalid coordinates for stop ${rec.stop_id}`);
        }
        return;
      }

      const safeName = rec.stop_name && rec.stop_name.trim().length > 0
        ? rec.stop_name
        : rec.stop_id;

      stopsMap.set(rec.stop_id, {
        id: rec.stop_id,
        code: rec.stop_code || rec.stop_id,
        name: safeName,
        latitude: lat,
        longitude: lon,
        modes: ['BUS'], // TODO: Route'lardan mod bilgisi çekilebilir
        lineIds: [], // TODO: Route-stop ilişkisinden doldurulabilir
      });
    });

    return stopsMap;
  } catch (error) {
    if (__DEV__) {
      console.error('[getStopsByIds] Error:', error);
    }
    return new Map();
  }
}

/**
 * Tüm stop'ları getir (cache'li)
 */
export async function getAllStops(): Promise<TransitStop[]> {
  if (!ULS_STOPS_RESOURCE_ID) {
    throw new Error('ULS_STOPS_RESOURCE_ID tanımlı değil');
  }

  // Cache kontrolü
  const cacheKey = 'stops:all';
  const cached = cache.get<TransitStop[]>(cacheKey);
  if (cached) {
    return cached;
  }

  const sql = `SELECT * FROM "${ULS_STOPS_RESOURCE_ID}"`;
  const records = await ckanSqlQuery<GtfsStopRecord>(ULS_STOPS_RESOURCE_ID, sql);

  const mapped: TransitStop[] = records
    .map((rec) => {
      const lat = typeof rec.stop_lat === 'string' ? parseFloat(rec.stop_lat) : rec.stop_lat;
      const lon = typeof rec.stop_lon === 'string' ? parseFloat(rec.stop_lon) : rec.stop_lon;

      if (isNaN(lat) || isNaN(lon)) {
        return null;
      }

      const safeName = rec.stop_name && rec.stop_name.trim().length > 0
        ? rec.stop_name
        : rec.stop_id;

      return {
        id: rec.stop_id,
        code: rec.stop_code || rec.stop_id,
        name: safeName,
        latitude: lat,
        longitude: lon,
        modes: ['BUS'] as TransitMode[],
        lineIds: [] as string[],
      };
    })
    .filter((stop): stop is TransitStop => stop !== null);

  // 1 saat cache
  cache.set(cacheKey, mapped, 60 * 60 * 1000);
  return mapped;
}

/**
 * Query ile stop arama
 */
export async function searchStops(query: string, limit = 25): Promise<TransitStop[]> {
  const trimmed = query.trim();
  if (!trimmed || trimmed.length < 2) {
    return [];
  }

  // Önce tüm stop'ları cache'den çek (zaten cache'li)
  const allStops = await getAllStops();
  const qLower = trimmed.toLocaleLowerCase('tr-TR');

  const filtered = allStops.filter((stop) => {
    const name = (stop.name ?? '').toLocaleLowerCase('tr-TR');
    const code = (stop.code ?? '').toLocaleLowerCase('tr-TR');
    return name.includes(qLower) || code.includes(qLower);
  });

  return filtered.slice(0, limit);
}

/**
 * Yakındaki stop'ları getir
 */
export async function getNearbyStops(
  lat: number,
  lon: number,
  radiusMeters: number,
  limit: number
): Promise<TransitStop[]> {
  const allStops = await getAllStops();

  const withDistance = allStops.map((stop) => {
    const distance = haversineDistanceMeters(lat, lon, stop.latitude, stop.longitude);
    return { stop, distance };
  });

  return withDistance
    .filter((item) => item.distance <= radiusMeters)
    .sort((a, b) => a.distance - b.distance)
    .slice(0, limit)
    .map((item) => item.stop);
}

/**
 * Belirli bir stop ID için stop detayı getir
 */
export async function getStopById(stopId: string): Promise<TransitStop | null> {
  const stopsMap = await getStopsByIds([stopId]);
  return stopsMap.get(stopId) || null;
}

// ============================================================================
// LINE STOPS (Route için sıralı durak listesi)
// ============================================================================

/**
 * Belirli bir route (line) için sıralı durak listesini getir
 * 
 * Algoritma:
 * 1. Route için trip'leri getir
 * 2. direction_id = 0 olan bir temsilci trip seç (yoksa ilkini al)
 * 3. Trip için stop_times'ları getir (zaten stop_sequence'e göre sıralı)
 * 4. Stop ID'leri çıkar ve sırasını koru
 * 5. Stop detaylarını toplu olarak getir
 * 6. Sıralı TransitStop listesi oluştur
 */
export async function getLineStops(routeId: string): Promise<TransitStop[]> {
  try {
    // 1. Route için trip'leri getir
    const trips = await getTripsByRoute(routeId);
    
    if (!trips || trips.length === 0) {
      if (__DEV__) {
        console.warn(`[getLineStops] route_id=${routeId} için trip bulunamadı`);
      }
      return [];
    }

    // 2. Temsilci trip seç - direction_id = 0 olanı tercih et
    let representativeTrip = trips.find((t) => t.direction_id === 0);
    if (!representativeTrip) {
      representativeTrip = trips[0];
    }

    const tripId = representativeTrip.trip_id;

    // 3. Trip için stop_times'ları getir (zaten stop_sequence ASC sıralı)
    const stopTimes = await getStopTimesByTrip(tripId);
    
    if (!stopTimes || stopTimes.length === 0) {
      if (__DEV__) {
        console.warn(`[getLineStops] trip_id=${tripId} için stop_times bulunamadı`);
      }
      return [];
    }

    // 4. Sıralı stop ID'lerini çıkar (duplicate'leri korumadan)
    const orderedStopIds: string[] = [];
    const seenStopIds = new Set<string>();

    for (const stopTime of stopTimes) {
      if (!seenStopIds.has(stopTime.stop_id)) {
        seenStopIds.add(stopTime.stop_id);
        orderedStopIds.push(stopTime.stop_id);
      }
    }

    // 5. Stop detaylarını toplu olarak getir
    const stopsMap = await getStopsByIds(orderedStopIds);

    // 6. Sıralı TransitStop listesi oluştur
    const lineStops: TransitStop[] = [];
    for (const stopId of orderedStopIds) {
      const stop = stopsMap.get(stopId);
      if (stop) {
        lineStops.push(stop);
      }
    }

    return lineStops;
  } catch (error) {
    if (__DEV__) {
      console.error(`[getLineStops] route_id=${routeId} için hata:`, error);
    }
    // Hata durumunda boş dizi döndür (kullanıcı deneyimini bozmamak için)
    return [];
  }
}

