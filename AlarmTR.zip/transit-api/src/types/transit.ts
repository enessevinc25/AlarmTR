export type TransitMode = 'BUS' | 'METROBUS' | 'TRAM' | 'METRO' | 'FERRY';

export interface TransitLine {
  id: string;
  code: string;    // Örn: "76O"
  name: string;    // Örn: "BAKIRKÖY - OTOGAR"
  mode: TransitMode;
}

export interface TransitStop {
  id: string;
  code: string;       // durak kodu
  name: string;
  latitude: number;
  longitude: number;
  modes: TransitMode[];
  lineIds: string[];  // Bu duraktan geçen hat id'leri
}

export interface LineStopRelation {
  lineId: string;
  stopId: string;
  order: number;       // hattaki sırası, istersen kullan
}

