/**
 * Main API endpoint tests
 * Tests all routes and error handling
 */

import request from 'supertest';
import express from 'express';

// Set NODE_ENV to test before importing
process.env.NODE_ENV = 'test';

// Mock the clients before importing the app
jest.mock('../src/clients/iettClient');
jest.mock('../src/clients/ulasavCkanClient');
jest.mock('../src/clients/ibbCkanClient');

// Import after mocks
import app from '../src/index';

describe('API Health Endpoints', () => {
  describe('GET /health', () => {
    it('should return 200 with ok status', async () => {
      const response = await request(app)
        .get('/health')
        .expect(200);

      expect(response.body).toEqual({
        ok: true,
        message: 'Transit API up',
      });
    });
  });

  describe('GET /places/health', () => {
    it('should return 200 with Google Places API status', async () => {
      const response = await request(app)
        .get('/places/health')
        .expect(200);

      expect(response.body).toHaveProperty('ok', true);
      expect(response.body).toHaveProperty('googlePlacesConfigured');
      expect(response.body).toHaveProperty('message');
    });

    it('should not expose API key', async () => {
      const response = await request(app)
        .get('/places/health')
        .expect(200);

      const apiKey = process.env.GOOGLE_MAPS_API_KEY;
      if (apiKey) {
        expect(JSON.stringify(response.body)).not.toContain(apiKey);
      } else {
        // API key yoksa googlePlacesConfigured false olmalı
        expect(response.body.googlePlacesConfigured).toBe(false);
      }
    });
  });
});

describe('GET /stops/search', () => {
  it('should return empty array for query less than 2 characters', async () => {
    const response = await request(app)
      .get('/stops/search?q=a')
      .expect(200);

    expect(response.body).toEqual({ stops: [] });
  });

  it('should return empty array for empty query', async () => {
    const response = await request(app)
      .get('/stops/search?q=')
      .expect(200);

    expect(response.body).toEqual({ stops: [] });
  });

  it('should handle search with valid query', async () => {
    // Mock the client
    const { searchStopsByNameOrCode } = require('../src/clients/iettClient');
    (searchStopsByNameOrCode as jest.Mock).mockResolvedValue([
      {
        id: 'stop-1',
        name: 'Test Stop',
        code: 'TST001',
        latitude: 41.0082,
        longitude: 28.9784,
        city: 'Istanbul',
      },
    ]);

    const response = await request(app)
      .get('/stops/search?q=test&limit=10')
      .expect(200);

    expect(response.body).toHaveProperty('stops');
    expect(Array.isArray(response.body.stops)).toBe(true);
    expect(searchStopsByNameOrCode).toHaveBeenCalledWith('test', 10);
  });

  it('should use default limit of 25', async () => {
    const { searchStopsByNameOrCode } = require('../src/clients/iettClient');
    (searchStopsByNameOrCode as jest.Mock).mockResolvedValue([]);

    await request(app)
      .get('/stops/search?q=test')
      .expect(200);

    expect(searchStopsByNameOrCode).toHaveBeenCalledWith('test', 25);
  });

  it('should handle errors gracefully', async () => {
    const { searchStopsByNameOrCode } = require('../src/clients/iettClient');
    (searchStopsByNameOrCode as jest.Mock).mockRejectedValue(new Error('Service unavailable'));

    const response = await request(app)
      .get('/stops/search?q=test')
      .expect(500);

    expect(response.body).toHaveProperty('error');
  });
});

describe('GET /stops/:id', () => {
  it('should return stop details for valid ID', async () => {
    const { getStopByIdFromIett } = require('../src/clients/iettClient');
    (getStopByIdFromIett as jest.Mock).mockResolvedValue({
      id: 'stop-1',
      name: 'Test Stop',
      code: 'TST001',
      latitude: 41.0082,
      longitude: 28.9784,
    });

    const response = await request(app)
      .get('/stops/stop-1')
      .expect(200);

    expect(response.body).toHaveProperty('stop');
    expect(response.body.stop).toHaveProperty('id', 'stop-1');
    expect(response.body.stop).toHaveProperty('name', 'Test Stop');
    expect(getStopByIdFromIett).toHaveBeenCalledWith('stop-1');
  });

  it('should return 404 for invalid ID', async () => {
    const { getStopByIdFromIett } = require('../src/clients/iettClient');
    (getStopByIdFromIett as jest.Mock).mockResolvedValue(null);

    await request(app)
      .get('/stops/invalid-id')
      .expect(404);
  });

  it('should handle errors', async () => {
    const { getStopByIdFromIett } = require('../src/clients/iettClient');
    (getStopByIdFromIett as jest.Mock).mockRejectedValue(new Error('Service error'));

    const response = await request(app)
      .get('/stops/stop-1')
      .expect(500);

    expect(response.body).toHaveProperty('error');
  });
});

describe('GET /lines', () => {
  it('should return all lines when no query provided', async () => {
    const { getAllLinesFromIett } = require('../src/clients/iettClient');
    (getAllLinesFromIett as jest.Mock).mockResolvedValue([
      {
        id: 'line-1',
        name: 'Test Line',
        code: 'TST',
        mode: 'BUS',
      },
    ]);

    const response = await request(app)
      .get('/lines')
      .expect(200);

    expect(response.body).toHaveProperty('lines');
    expect(Array.isArray(response.body.lines)).toBe(true);
    expect(getAllLinesFromIett).toHaveBeenCalled();
  });

  it('should handle search with valid query', async () => {
    const { searchLinesByQuery } = require('../src/clients/iettClient');
    (searchLinesByQuery as jest.Mock).mockResolvedValue([
      {
        id: 'line-1',
        name: 'Test Line',
        code: 'TST',
        mode: 'BUS',
      },
    ]);

    const response = await request(app)
      .get('/lines?q=test')
      .expect(200);

    expect(response.body).toHaveProperty('lines');
    expect(Array.isArray(response.body.lines)).toBe(true);
    expect(searchLinesByQuery).toHaveBeenCalledWith('test');
  });

  it('should filter by mode when provided', async () => {
    const { getAllLinesFromIett } = require('../src/clients/iettClient');
    (getAllLinesFromIett as jest.Mock).mockResolvedValue([
      { id: 'line-1', name: 'Bus Line', mode: 'BUS' },
      { id: 'line-2', name: 'Metro Line', mode: 'METRO' },
    ]);

    const response = await request(app)
      .get('/lines?mode=BUS')
      .expect(200);

    expect(response.body.lines).toHaveLength(1);
    expect(response.body.lines[0].mode).toBe('BUS');
  });

  it('should handle errors gracefully', async () => {
    const { getAllLinesFromIett } = require('../src/clients/iettClient');
    (getAllLinesFromIett as jest.Mock).mockRejectedValue(new Error('Service error'));

    const response = await request(app)
      .get('/lines')
      .expect(500);

    expect(response.body).toHaveProperty('error');
  });
});

describe('GET /lines/:id/stops', () => {
  it('should return 400 for missing lineId', async () => {
    const response = await request(app)
      .get('/lines//stops')
      .expect(404); // Express treats // as invalid route
  });

  it('should return line stops for valid line ID', async () => {
    const { getLineStopsFromIett } = require('../src/clients/iettClient');
    (getLineStopsFromIett as jest.Mock).mockResolvedValue({
      line: {
        id: 'line-1',
        name: 'Test Line',
        code: 'TST',
        mode: 'BUS',
      },
      stops: [
        {
          id: 'stop-1',
          name: 'Stop 1',
          order: 1,
          direction: 'INBOUND',
        },
      ],
    });

    const response = await request(app)
      .get('/lines/line-1/stops')
      .expect(200);

    expect(response.body).toHaveProperty('line');
    expect(response.body).toHaveProperty('stops');
    expect(Array.isArray(response.body.stops)).toBe(true);
    expect(response.body.stops.length).toBeGreaterThan(0);
  });

  it('should return 404 for invalid line ID', async () => {
    const { getLineStopsFromIett } = require('../src/clients/iettClient');
    (getLineStopsFromIett as jest.Mock).mockResolvedValue({
      line: null,
      stops: [],
    });

    const response = await request(app)
      .get('/lines/invalid-id/stops')
      .expect(404);

    expect(response.body).toHaveProperty('error');
    expect(response.body.error).toContain('bulunamadı');
  });

  it('should handle errors gracefully', async () => {
    const { getLineStopsFromIett } = require('../src/clients/iettClient');
    (getLineStopsFromIett as jest.Mock).mockRejectedValue(new Error('Service error'));

    const response = await request(app)
      .get('/lines/line-1/stops')
      .expect(500);

    expect(response.body).toHaveProperty('error');
  });
});

describe('GET /places/autocomplete', () => {
  beforeEach(() => {
    // Set GOOGLE_MAPS_API_KEY for tests
    process.env.GOOGLE_MAPS_API_KEY = 'test-api-key';
    jest.clearAllMocks();
  });

  afterEach(() => {
    delete process.env.GOOGLE_MAPS_API_KEY;
  });

  it('should return 400 for missing input', async () => {
    const response = await request(app)
      .get('/places/autocomplete')
      .expect(400);

    expect(response.body).toHaveProperty('error');
    expect(response.body.error).toContain('input parametresi');
  });

  it('should return 400 for input less than 2 characters', async () => {
    const response = await request(app)
      .get('/places/autocomplete?input=a')
      .expect(400);

    expect(response.body).toHaveProperty('error');
  });

  it('should return 400 for input longer than 200 characters', async () => {
    const longInput = 'a'.repeat(201);
    const response = await request(app)
      .get(`/places/autocomplete?input=${encodeURIComponent(longInput)}`)
      .expect(400);

    expect(response.body).toHaveProperty('error');
    expect(response.body.error).toContain('çok uzun');
  });

  it('should return 503 when GOOGLE_MAPS_API_KEY is not set', async () => {
    delete process.env.GOOGLE_MAPS_API_KEY;
    
    const response = await request(app)
      .get('/places/autocomplete?input=test')
      .expect(503);

    expect(response.body).toHaveProperty('error');
    expect(response.body.error).toContain('yapılandırması eksik');
  });

  it('should return suggestions for valid query', async () => {
    // Mock fetch for Google Places API
    global.fetch = jest.fn().mockResolvedValue({
      ok: true,
      json: async () => ({
        status: 'OK',
        predictions: [
          {
            place_id: 'place-1',
            description: 'Test Place, Istanbul',
            structured_formatting: {
              main_text: 'Test Place',
              secondary_text: 'Istanbul',
            },
          },
        ],
      }),
    });

    const response = await request(app)
      .get('/places/autocomplete?input=test&language=tr')
      .expect(200);

    expect(response.body).toHaveProperty('suggestions');
    expect(Array.isArray(response.body.suggestions)).toBe(true);
    expect(response.body.suggestions.length).toBeGreaterThan(0);
    expect(response.body.suggestions[0]).toHaveProperty('placeId', 'place-1');
    expect(response.body.suggestions[0]).toHaveProperty('description');
  });

  it('should handle ZERO_RESULTS status', async () => {
    global.fetch = jest.fn().mockResolvedValue({
      ok: true,
      json: async () => ({
        status: 'ZERO_RESULTS',
        predictions: [],
      }),
    });

    const response = await request(app)
      .get('/places/autocomplete?input=nonexistent')
      .expect(200);

    expect(response.body).toHaveProperty('suggestions');
    expect(Array.isArray(response.body.suggestions)).toBe(true);
    expect(response.body.suggestions.length).toBe(0);
  });

  it('should handle Google Places API errors', async () => {
    global.fetch = jest.fn().mockResolvedValue({
      ok: false,
      status: 429,
      json: async () => ({ error: 'Too many requests' }),
    });

    const response = await request(app)
      .get('/places/autocomplete?input=test')
      .expect(502);

    expect(response.body).toHaveProperty('error');
  });

  it('should handle REQUEST_DENIED status', async () => {
    global.fetch = jest.fn().mockResolvedValue({
      ok: true,
      json: async () => ({
        status: 'REQUEST_DENIED',
        error_message: 'API key invalid',
      }),
    });

    const response = await request(app)
      .get('/places/autocomplete?input=test')
      .expect(502);

    expect(response.body).toHaveProperty('error');
  });

  it('should handle OVER_QUERY_LIMIT status', async () => {
    global.fetch = jest.fn().mockResolvedValue({
      ok: true,
      json: async () => ({
        status: 'OVER_QUERY_LIMIT',
      }),
    });

    const response = await request(app)
      .get('/places/autocomplete?input=test')
      .expect(502);

    expect(response.body).toHaveProperty('error');
  });
});

describe('GET /places/details', () => {
  beforeEach(() => {
    process.env.GOOGLE_MAPS_API_KEY = 'test-api-key';
    jest.clearAllMocks();
  });

  afterEach(() => {
    delete process.env.GOOGLE_MAPS_API_KEY;
  });

  it('should return 400 for missing placeId', async () => {
    const response = await request(app)
      .get('/places/details')
      .expect(400);

    expect(response.body).toHaveProperty('error');
    expect(response.body.error).toContain('placeId parametresi');
  });

  it('should return 503 when GOOGLE_MAPS_API_KEY is not set', async () => {
    delete process.env.GOOGLE_MAPS_API_KEY;
    
    const response = await request(app)
      .get('/places/details?placeId=test-place-id')
      .expect(503);

    expect(response.body).toHaveProperty('error');
    expect(response.body.error).toContain('yapılandırması eksik');
  });

  it('should return place details for valid placeId', async () => {
    global.fetch = jest.fn().mockResolvedValue({
      ok: true,
      json: async () => ({
        status: 'OK',
        result: {
          place_id: 'place-1',
          name: 'Test Place',
          geometry: {
            location: {
              lat: 41.0082,
              lng: 28.9784,
            },
          },
          formatted_address: 'Test Address, Istanbul',
        },
      }),
    });

    const response = await request(app)
      .get('/places/details?placeId=place-1&language=tr')
      .expect(200);

    expect(response.body).toHaveProperty('placeId', 'place-1');
    expect(response.body).toHaveProperty('name', 'Test Place');
    expect(response.body).toHaveProperty('latitude', 41.0082);
    expect(response.body).toHaveProperty('longitude', 28.9784);
    expect(response.body).toHaveProperty('address', 'Test Address, Istanbul');
  });

  it('should return 404 for NOT_FOUND status', async () => {
    global.fetch = jest.fn().mockResolvedValue({
      ok: true,
      json: async () => ({
        status: 'NOT_FOUND',
      }),
    });

    const response = await request(app)
      .get('/places/details?placeId=invalid-place-id')
      .expect(404);

    expect(response.body).toHaveProperty('error');
    expect(response.body.error).toContain('bulunamadı');
  });

  it('should return 502 for REQUEST_DENIED status', async () => {
    global.fetch = jest.fn().mockResolvedValue({
      ok: true,
      json: async () => ({
        status: 'REQUEST_DENIED',
        error_message: 'API key invalid',
      }),
    });

    const response = await request(app)
      .get('/places/details?placeId=test-place-id')
      .expect(502);

    expect(response.body).toHaveProperty('error');
    expect(response.body.error).toContain('erişim reddedildi');
  });

  it('should return 502 for OVER_QUERY_LIMIT status', async () => {
    global.fetch = jest.fn().mockResolvedValue({
      ok: true,
      json: async () => ({
        status: 'OVER_QUERY_LIMIT',
      }),
    });

    const response = await request(app)
      .get('/places/details?placeId=test-place-id')
      .expect(502);

    expect(response.body).toHaveProperty('error');
    expect(response.body.error).toContain('kotası aşıldı');
  });

  it('should return 502 for invalid place details structure', async () => {
    global.fetch = jest.fn().mockResolvedValue({
      ok: true,
      json: async () => ({
        status: 'OK',
        result: {
          // Missing geometry.location
          name: 'Test Place',
        },
      }),
    });

    const response = await request(app)
      .get('/places/details?placeId=test-place-id')
      .expect(502);

    expect(response.body).toHaveProperty('error');
  });

  it('should handle Google API HTTP errors', async () => {
    global.fetch = jest.fn().mockResolvedValue({
      ok: false,
      status: 500,
    });

    const response = await request(app)
      .get('/places/details?placeId=test-place-id')
      .expect(502);

    expect(response.body).toHaveProperty('error');
    expect(response.body.error).toContain('Google Places API hatası');
  });
});

describe('Rate Limiting', () => {
  it('should allow health endpoints without rate limiting', async () => {
    // Make multiple requests to /health
    for (let i = 0; i < 10; i++) {
      await request(app)
        .get('/health')
        .expect(200);
    }
  });

  it('should rate limit /stops/search after many requests', async () => {
    const { searchStopsByNameOrCode } = require('../src/clients/iettClient');
    (searchStopsByNameOrCode as jest.Mock).mockResolvedValue([]);

    // Make many requests (rate limit is 300 per 15 minutes, but we can test with smaller window)
    let rateLimited = false;
    for (let i = 0; i < 5; i++) {
      const response = await request(app)
        .get('/stops/search?q=test');

      if (response.status === 429) {
        rateLimited = true;
        expect(response.body).toHaveProperty('error');
        break;
      }
    }

    // Note: In real scenario, rate limiting would kick in after 300 requests
    // This test just verifies the endpoint exists and rate limiter is configured
    expect(searchStopsByNameOrCode).toHaveBeenCalled();
  });
});

describe('Error Handling', () => {
  it('should return 404 for unknown routes', async () => {
    const response = await request(app)
      .get('/unknown/route')
      .expect(404);

    expect(response.body).toHaveProperty('error');
  });
});

