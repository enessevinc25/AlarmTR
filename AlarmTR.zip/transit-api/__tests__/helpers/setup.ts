/**
 * Jest test setup
 * Global test configuration
 */

// Mock environment variables for tests
process.env.PORT = '4000';
// GOOGLE_MAPS_API_KEY test için set edilmezse undefined kalır (test senaryosu için)
// Testlerde guard ile kontrol edilir
if (!process.env.GOOGLE_MAPS_API_KEY) {
  process.env.GOOGLE_MAPS_API_KEY = 'DUMMY_TEST_KEY';
}

// Increase timeout for API tests
jest.setTimeout(10000);

