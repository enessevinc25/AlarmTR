# Google Cloud Run Otomatik Deploy Script
# Kullanım: .\deploy-cloud-run.ps1

$PROJECT_ID = "laststop-alarm-tr-38d76"
$SERVICE_NAME = "laststop-alarm-tr"
$REGION = "europe-west1"

Write-Host "========================================" -ForegroundColor Cyan
Write-Host "Google Cloud Run Deploy Script" -ForegroundColor Cyan
Write-Host "========================================" -ForegroundColor Cyan
Write-Host ""

# gcloud kontrolü
Write-Host "[1/7] gcloud CLI kontrolü..." -ForegroundColor Yellow
try {
    $gcloudVersion = gcloud --version 2>&1
    Write-Host "✅ gcloud bulundu" -ForegroundColor Green
    Write-Host $gcloudVersion[0] -ForegroundColor Gray
} catch {
    Write-Host "❌ gcloud bulunamadı!" -ForegroundColor Red
    Write-Host ""
    Write-Host "Lütfen önce Google Cloud SDK'yı kurun:" -ForegroundColor Yellow
    Write-Host "1. https://cloud.google.com/sdk/docs/install adresine gidin" -ForegroundColor White
    Write-Host "2. Windows için SDK'yı indirin ve kurun" -ForegroundColor White
    Write-Host "3. PowerShell'i yeniden başlatın" -ForegroundColor White
    Write-Host "4. Bu script'i tekrar çalıştırın" -ForegroundColor White
    exit 1
}

# Proje ayarlama
Write-Host ""
Write-Host "[2/7] Proje ayarlanıyor: $PROJECT_ID" -ForegroundColor Yellow
gcloud config set project $PROJECT_ID
if ($LASTEXITCODE -ne 0) {
    Write-Host "❌ Proje ayarlanamadı!" -ForegroundColor Red
    Write-Host "Proje ID'nizi kontrol edin veya gcloud auth login yapın" -ForegroundColor Yellow
    exit 1
}
Write-Host "✅ Proje ayarlandı" -ForegroundColor Green

# API'leri aktifleştir
Write-Host ""
Write-Host "[3/7] Gerekli API'ler aktifleştiriliyor..." -ForegroundColor Yellow
gcloud services enable run.googleapis.com --quiet
gcloud services enable cloudbuild.googleapis.com --quiet
gcloud services enable containerregistry.googleapis.com --quiet
Write-Host "✅ API'ler aktifleştirildi" -ForegroundColor Green

# Dockerfile kontrolü
Write-Host ""
Write-Host "[4/7] Dockerfile kontrolü..." -ForegroundColor Yellow
if (-not (Test-Path "Dockerfile")) {
    Write-Host "❌ Dockerfile bulunamadı!" -ForegroundColor Red
    exit 1
}
Write-Host "✅ Dockerfile bulundu" -ForegroundColor Green

# Deploy
Write-Host ""
Write-Host "[5/7] Cloud Run'a deploy ediliyor..." -ForegroundColor Yellow
Write-Host "Bu işlem 5-10 dakika sürebilir..." -ForegroundColor Gray
Write-Host ""

# Google Maps API Key - Cloud Run environment variable veya Secret Manager'dan alınacak
# ÖNEMLİ: Production'da Secret Manager kullanılması önerilir (daha güvenli)
# Local development için .env dosyasında set edin
# 
# Seçenek 1: Environment variable (hızlı test için)
# Seçenek 2: Secret Manager (production için önerilir - aşağıdaki yorumları kullanın)

$USE_SECRET_MANAGER = $false  # true yaparsanız Secret Manager kullanılır

if ($USE_SECRET_MANAGER) {
    Write-Host "[5/7] Secret Manager'dan GOOGLE_MAPS_API_KEY alınıyor..." -ForegroundColor Yellow
    $SECRET_NAME = "google-maps-api-key"
    
    # Secret'ın var olup olmadığını kontrol et
    $secretExists = gcloud secrets describe $SECRET_NAME --project $PROJECT_ID 2>&1
    if ($LASTEXITCODE -ne 0) {
        Write-Host "⚠️ Secret '$SECRET_NAME' bulunamadı. Oluşturuluyor..." -ForegroundColor Yellow
        Write-Host "   Lütfen API key'inizi girin:" -ForegroundColor White
        $apiKeyValue = Read-Host -AsSecureString | ConvertFrom-SecureString -AsPlainText
        echo $apiKeyValue | gcloud secrets create $SECRET_NAME --data-file=- --project $PROJECT_ID
        if ($LASTEXITCODE -ne 0) {
            Write-Host "❌ Secret oluşturulamadı!" -ForegroundColor Red
            exit 1
        }
    }
    Write-Host "✅ Secret Manager kullanılacak: $SECRET_NAME" -ForegroundColor Green
} else {
    # Environment variable kullan
    if (-not $env:GOOGLE_MAPS_API_KEY) {
        Write-Host "❌ HATA: GOOGLE_MAPS_API_KEY environment variable set edilmemiş!" -ForegroundColor Red
        Write-Host "   Cloud Run deployment için GOOGLE_MAPS_API_KEY environment variable'ı gereklidir." -ForegroundColor Red
        Write-Host "   Örnek: `$env:GOOGLE_MAPS_API_KEY='your-api-key'" -ForegroundColor Yellow
        Write-Host "" -ForegroundColor Yellow
        Write-Host "   VEYA Secret Manager kullanmak için script'te USE_SECRET_MANAGER=true yapın" -ForegroundColor Yellow
        exit 1
    }
    $GOOGLE_MAPS_API_KEY = $env:GOOGLE_MAPS_API_KEY
    Write-Host "✅ Environment variable kullanılıyor" -ForegroundColor Green
}

# Deploy komutu (Secret Manager veya environment variable'a göre)
if ($USE_SECRET_MANAGER) {
    # Secret Manager kullan
    gcloud run deploy $SERVICE_NAME `
        --source . `
        --region $REGION `
        --allow-unauthenticated `
        --memory 512Mi `
        --cpu 1 `
        --min-instances 0 `
        --max-instances 10 `
        --timeout 300 `
        --port 8080 `
        --update-secrets "GOOGLE_MAPS_API_KEY=$SECRET_NAME:latest" `
        --project $PROJECT_ID
} else {
    # Environment variable kullan
    gcloud run deploy $SERVICE_NAME `
        --source . `
        --region $REGION `
        --allow-unauthenticated `
        --memory 512Mi `
        --cpu 1 `
        --min-instances 0 `
        --max-instances 10 `
        --timeout 300 `
        --port 8080 `
        --set-env-vars "GOOGLE_MAPS_API_KEY=$GOOGLE_MAPS_API_KEY" `
        --project $PROJECT_ID
}

if ($LASTEXITCODE -ne 0) {
    Write-Host ""
    Write-Host "❌ Deploy başarısız oldu!" -ForegroundColor Red
    Write-Host "Logları kontrol edin: gcloud run services logs read $SERVICE_NAME --region $REGION" -ForegroundColor Yellow
    exit 1
}

# Service URL'i al
Write-Host ""
Write-Host "[6/7] Service URL alınıyor..." -ForegroundColor Yellow
$SERVICE_URL = gcloud run services describe $SERVICE_NAME --region $REGION --format "value(status.url)" --project $PROJECT_ID

if (-not $SERVICE_URL) {
    Write-Host "❌ Service URL alınamadı!" -ForegroundColor Red
    exit 1
}

Write-Host ""
Write-Host "========================================" -ForegroundColor Green
Write-Host "✅ DEPLOY BAŞARILI!" -ForegroundColor Green
Write-Host "========================================" -ForegroundColor Green
Write-Host ""
Write-Host "Service URL: $SERVICE_URL" -ForegroundColor Cyan
Write-Host ""

# Healthcheck testi
Write-Host "[7/7] Healthcheck testi yapılıyor..." -ForegroundColor Yellow
try {
    # Ana healthcheck
    $healthResponse = Invoke-WebRequest -Uri "$SERVICE_URL/health" -UseBasicParsing -TimeoutSec 10
    if ($healthResponse.StatusCode -eq 200) {
        Write-Host "✅ Healthcheck başarılı!" -ForegroundColor Green
        Write-Host "Response: $($healthResponse.Content)" -ForegroundColor Gray
    } else {
        Write-Host "⚠️ Healthcheck yanıt kodu: $($healthResponse.StatusCode)" -ForegroundColor Yellow
    }
    
    # Places healthcheck (Google Places API yapılandırmasını kontrol eder)
    Write-Host "" -ForegroundColor Gray
    Write-Host "Places healthcheck testi yapılıyor..." -ForegroundColor Yellow
    try {
        $placesHealthResponse = Invoke-WebRequest -Uri "$SERVICE_URL/places/health" -UseBasicParsing -TimeoutSec 10
        if ($placesHealthResponse.StatusCode -eq 200) {
            $placesHealthJson = $placesHealthResponse.Content | ConvertFrom-Json
            if ($placesHealthJson.googlePlacesConfigured) {
                Write-Host "✅ Places API yapılandırılmış!" -ForegroundColor Green
            } else {
                Write-Host "⚠️ Places API yapılandırılmamış!" -ForegroundColor Yellow
                Write-Host "   GOOGLE_MAPS_API_KEY environment variable'ı kontrol edin" -ForegroundColor Yellow
            }
            Write-Host "Response: $($placesHealthResponse.Content)" -ForegroundColor Gray
        }
    } catch {
        Write-Host "⚠️ Places healthcheck testi başarısız: $($_.Exception.Message)" -ForegroundColor Yellow
    }
} catch {
    Write-Host "⚠️ Healthcheck testi başarısız: $($_.Exception.Message)" -ForegroundColor Yellow
    Write-Host "Service URL'i manuel olarak test edin: $SERVICE_URL/health" -ForegroundColor Yellow
}

Write-Host ""
Write-Host "========================================" -ForegroundColor Cyan
Write-Host "SONRAKI ADIMLAR" -ForegroundColor Cyan
Write-Host "========================================" -ForegroundColor Cyan
Write-Host ""
Write-Host "1. Production URL'i eas.json'a ekleyin:" -ForegroundColor White
Write-Host "   $SERVICE_URL" -ForegroundColor Cyan
Write-Host ""
Write-Host "2. NOT: Transit API URL artık hardcoded (src/utils/env.ts), EAS Secret gerekmez" -ForegroundColor Yellow
Write-Host ""
Write-Host "3. API testi:" -ForegroundColor White
Write-Host "   # Durak arama:" -ForegroundColor Gray
Write-Host "   curl `"$SERVICE_URL/stops/search?q=zincirlikuyu&limit=5`"" -ForegroundColor Cyan
Write-Host "   # Places healthcheck:" -ForegroundColor Gray
Write-Host "   curl `"$SERVICE_URL/places/health`"" -ForegroundColor Cyan
Write-Host ""
Write-Host "4. Logları görüntüle:" -ForegroundColor White
Write-Host "   gcloud run services logs read $SERVICE_NAME --region $REGION" -ForegroundColor Cyan
Write-Host ""
Write-Host "5. Environment variables güncelleme:" -ForegroundColor White
if ($USE_SECRET_MANAGER) {
    Write-Host "   # Secret Manager kullanılıyor, güncelleme için:" -ForegroundColor Gray
    Write-Host "   echo 'your-new-api-key' | gcloud secrets versions add google-maps-api-key --data-file=-" -ForegroundColor Cyan
} else {
    Write-Host "   # Environment variable güncelleme:" -ForegroundColor Gray
    Write-Host "   gcloud run services update $SERVICE_NAME --region $REGION --set-env-vars `"GOOGLE_MAPS_API_KEY=your-new-key`"" -ForegroundColor Cyan
}
Write-Host ""

# URL'i dosyaya kaydet
$SERVICE_URL | Out-File -FilePath "production-url.txt" -Encoding utf8
Write-Host "✅ Production URL 'production-url.txt' dosyasına kaydedildi" -ForegroundColor Green
Write-Host ""

