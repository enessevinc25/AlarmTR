# Transit API - Google Cloud Run Deployment

Bu dosya, transit-api backend'inizi Google Cloud Run'a deploy etmek için hızlı başlangıç rehberidir.

## 📚 Detaylı Rehber

**Ana rehber:** `GOOGLE_CLOUD_RUN_DEPLOY_REHBERI.md` dosyasına bakın (proje root'unda)

## ⚡ Hızlı Başlangıç

### 0. Local Development Setup (İsteğe Bağlı)

Local development için environment variables'ları ayarlayın:

```powershell
# Windows
cd transit-api
copy env.sample .env

# Mac/Linux
cd transit-api
cp env.sample .env
```

Sonra `.env` dosyasını düzenleyip gerçek değerleri girin (özellikle `GOOGLE_MAPS_API_KEY` zorunludur).

### 1. Google Cloud CLI Kurulumu

```powershell
# Google Cloud SDK indirin ve kurun
# https://cloud.google.com/sdk/docs/install

# Kurulumu doğrula
gcloud --version
```

### 2. Google Cloud'a Giriş

```powershell
# Google hesabınıza giriş yapın
gcloud auth login

# Proje oluşturun (Google Cloud Console'dan) ve ayarlayın
gcloud config set project YOUR_PROJECT_ID
```

### 3. API'leri Aktifleştir

```powershell
gcloud services enable run.googleapis.com
gcloud services enable cloudbuild.googleapis.com
gcloud services enable containerregistry.googleapis.com
```

### 4. Deploy

```powershell
# transit-api klasörüne gidin
cd transit-api

# Cloud Run'a deploy edin
gcloud run deploy transit-api \
  --source . \
  --region europe-west1 \
  --allow-unauthenticated \
  --memory 512Mi \
  --cpu 1 \
  --min-instances 0 \
  --max-instances 10 \
  --timeout 300 \
  --port 8080
```

### 5. Production URL'i Al

Deploy sonrası verilen URL'i kopyalayın:
```
https://transit-api-xxxxx-ew.a.run.app
```

### 6. Test

```powershell
# Healthcheck
curl https://transit-api-xxxxx-ew.a.run.app/health

# API test
curl "https://transit-api-xxxxx-ew.a.run.app/stops/search?q=zincirlikuyu&limit=5"
```

### 7. eas.json'a Ekle

Production URL'i `eas.json` dosyasına ekleyin veya EAS Secrets kullanın:

```powershell
# NOT: Transit API URL artık hardcoded (src/utils/env.ts), EAS Secret gerekmez
```

## 📁 Oluşturulan Dosyalar

- ✅ `Dockerfile` - Docker image tanımı
- ✅ `.dockerignore` - Docker build'de ignore edilecek dosyalar
- ✅ `.gcloudignore` - Cloud Build'de ignore edilecek dosyalar
- ✅ `cloudbuild.yaml` - CI/CD için Cloud Build config (opsiyonel)

## 🔄 Güncelleme

Kod değişikliği yaptıktan sonra:

```powershell
cd transit-api
gcloud run deploy transit-api --source . --region europe-west1
```

## 🔐 Required Environment Variables

Cloud Run deploy ederken environment variables'ları set etmeniz gerekir:

```powershell
# Google Maps API Key (Places Autocomplete/Details proxy için zorunlu)
gcloud run services update transit-api \
  --region europe-west1 \
  --set-env-vars GOOGLE_MAPS_API_KEY=your_google_maps_api_key_here

# Ulasav CKAN Resource IDs (GTFS data için)
gcloud run services update transit-api \
  --region europe-west1 \
  --set-env-vars ULS_ROUTES_RESOURCE_ID=your_routes_resource_id \
  --set-env-vars ULS_TRIPS_RESOURCE_ID=your_trips_resource_id \
  --set-env-vars ULS_STOPS_RESOURCE_ID=your_stops_resource_id \
  --set-env-vars ULS_STOP_TIMES_RESOURCE_ID=your_stop_times_resource_id
```

### Environment Variables Listesi

| Variable | Zorunlu | Açıklama |
|----------|---------|----------|
| `GOOGLE_MAPS_API_KEY` | ✅ **Evet** | Places Autocomplete/Details proxy için Google Maps API key |
| `ULS_ROUTES_RESOURCE_ID` | ⚠️ Uyarı | Ulasav CKAN routes resource ID (route işlemleri için) |
| `ULS_TRIPS_RESOURCE_ID` | ⚠️ Uyarı | Ulasav CKAN trips resource ID (trip işlemleri için) |
| `ULS_STOPS_RESOURCE_ID` | ⚠️ Uyarı | Ulasav CKAN stops resource ID (stop işlemleri için) |
| `ULS_STOP_TIMES_RESOURCE_ID` | ⚠️ Uyarı | Ulasav CKAN stop_times resource ID (stop_times işlemleri için) |
| `ULS_CKAN_BASE_URL` | ❌ Hayır | Ulasav CKAN base URL (varsayılan: https://ulasav.csb.gov.tr/api/3/action) |
| `IETT_BASE_URL` | ❌ Hayır | İBB IETT base URL (varsayılan: https://api.ibb.gov.tr/iett) |

### Local Development Setup

Local development için environment variables'ları ayarlayın:

```powershell
# Windows
cd transit-api
copy env.sample .env

# Mac/Linux
cd transit-api
cp env.sample .env
```

Sonra `.env` dosyasını düzenleyip gerçek değerleri girin (özellikle `GOOGLE_MAPS_API_KEY` zorunludur).

## 📖 Daha Fazla Bilgi

- **Detaylı Rehber:** `GOOGLE_CLOUD_RUN_DEPLOY_REHBERI.md`
- **Checklist:** `DEPLOYMENT_CHECKLIST.md`
- **Production URL Rehberi:** `PRODUCTION_API_URL_REHBERI.md`

