# Google Maps API Keys - Güncelleme Rehberi

## 📱 Mobil Uygulama API Keys (Güncellendi - 2025)

Mobil uygulama için platform-specific API key'ler EAS Environment Variables'a kaydedildi:

- **Android**: `AIzaSyAVU7hqKkF7p3yHIFn_ykwJG2PTTIMyg2g`
- **iOS**: `AIzaSyDsm7bYfryNWjJppXCYGHGvYBhFjcMXR0w`

### EAS Secrets Güncelleme

```powershell
# Root dizinde
.\scripts\update-google-maps-keys.ps1
```

Veya manuel olarak:

```powershell
# Android
echo "AIzaSyAVU7hqKkF7p3yHIFn_ykwJG2PTTIMyg2g" | eas secret:create --scope project --name EXPO_PUBLIC_GOOGLE_MAPS_API_KEY_ANDROID --value-from-stdin

# iOS
echo "AIzaSyDsm7bYfryNWjJppXCYGHGvYBhFjcMXR0w" | eas secret:create --scope project --name EXPO_PUBLIC_GOOGLE_MAPS_API_KEY_IOS --value-from-stdin
```

## 🔧 Backend (Cloud Run) API Key (Güncellendi - 2025)

**✅ TAMAMLANDI:** Backend için **SERVER-SIDE** API key oluşturuldu ve deploy edildi!

- **Server-Side Key**: `AIzaSyALEHjwVi3HGBYVQvWFHSY0YJTLefczc9A`
- **Service URL**: `https://laststop-alarm-tr-599735223710.europe-west1.run.app`
- **Status**: ✅ Deployed ve çalışıyor

### ✅ Server-Side Key Oluşturuldu ve Deploy Edildi

**Key**: `AIzaSyALEHjwVi3HGBYVQvWFHSY0YJTLefczc9A`
**Service**: `laststop-alarm-tr`
**Region**: `europe-west1`
**URL**: `https://laststop-alarm-tr-599735223710.europe-west1.run.app`

### Backend Güncelleme (Key Değişikliği)

```powershell
# Server-side key ile deploy (güncel key)
$env:GOOGLE_MAPS_API_KEY="AIzaSyALEHjwVi3HGBYVQvWFHSY0YJTLefczc9A"
cd transit-api
.\deploy-cloud-run.ps1

# VEYA mevcut service'i güncelle
gcloud run services update laststop-alarm-tr --region europe-west1 --set-env-vars "GOOGLE_MAPS_API_KEY=AIzaSyALEHjwVi3HGBYVQvWFHSY0YJTLefczc9A" --project laststop-alarm-tr-38d76
```

### Secret Manager ile (Önerilen)

```powershell
# Secret oluştur
echo -n "your-server-side-api-key" | gcloud secrets create google-maps-api-key --data-file=- --project laststop-alarm-tr-38d76

# Secret Manager ile deploy
$env:USE_SECRET_MANAGER="true"
cd transit-api
.\deploy-cloud-run.ps1
```

## 🔍 Key Kontrolü

### Mobil Uygulama

```powershell
# EAS Secrets listesi
eas secret:list --scope project
```

### Backend

```powershell
# Cloud Run environment variables
gcloud run services describe laststop-alarm-tr --region europe-west1 --format "value(spec.template.spec.containers[0].env)" --project laststop-alarm-tr-38d76

# VEYA Secret Manager
gcloud secrets versions access latest --secret="google-maps-api-key" --project laststop-alarm-tr-38d76
```

## ⚠️ Güvenlik Notları

1. **Mobil key'ler** client-side bundle'a gömülür (EXPO_PUBLIC_* değişkenleri)
   - Android/iOS app restrictions ile korunmalı
   - Bundle ID / Package name restrictions ekleyin

2. **Backend key** server-side'da kalmalı
   - Asla client bundle'a gömülmemeli
   - IP restrictions ile korunmalı
   - Secret Manager kullanılması önerilir

3. **API Restrictions**:
   - Mobil key'ler: Maps SDK for Android, Maps SDK for iOS
   - Backend key: Places API

## 📚 Daha Fazla Bilgi

- [Google Maps API Key Restrictions](https://developers.google.com/maps/api-security-best-practices)
- [EAS Secrets Documentation](https://docs.expo.dev/build-reference/variables/)
- [Cloud Run Secrets](https://cloud.google.com/run/docs/configuring/secrets)

