/**
 * @deprecated AlarmProfilesScreen kullanılmalı.
 */

